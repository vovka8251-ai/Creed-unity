package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.FactionTier
import com.example.game.audio.GameAudioEngine
import com.example.game.engine.GameEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Creed Unity", appName)
    }

    @Test
    fun `test faction tier classification`() {
        assertEquals(FactionTier.HATED, FactionTier.getTier(-50))
        assertEquals(FactionTier.SUSPICIOUS, FactionTier.getTier(-10))
        assertEquals(FactionTier.NEUTRAL, FactionTier.getTier(20))
        assertEquals(FactionTier.FRIENDLY, FactionTier.getTier(50))
        assertEquals(FactionTier.ALLIED, FactionTier.getTier(85))
    }

    @Test
    fun `test game engine open world initial entities and public acts`() {
        val engine = GameEngine(
            audioEngine = GameAudioEngine(),
            vibrator = null
        )
        assertTrue(engine.buildings.isNotEmpty())
        assertTrue(engine.crowds.isNotEmpty())
        assertTrue(engine.prisonerCages.isNotEmpty())
        assertTrue(engine.viewpoints.isNotEmpty())

        var deltaReceived = 0
        var factionTarget = ""
        engine.onFactionStandingChanged = { fac, delta, _ ->
            factionTarget = fac
            deltaReceived += delta
        }

        // Test crowd riot public act
        val riotResult = engine.tossCoinsAndInciteRiot()
        assertTrue(riotResult)
        assertTrue(deltaReceived > 0)
    }
}
