package com.example

import android.os.Bundle
import android.view.KeyEvent
import android.view.MotionEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.game.controller.GamepadHandler
import com.example.game.controller.GamepadInputState
import com.example.ui.components.GameCanvas
import com.example.ui.components.GameHud
import com.example.ui.screens.FactionVendorScreen
import com.example.ui.screens.FactionsScreen
import com.example.ui.screens.MissionsScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.viewmodel.GameViewModel
import com.example.ui.viewmodel.ScreenTab

class MainActivity : ComponentActivity() {
    private val viewModel: GameViewModel by viewModels()
    private var internalGamepadState = GamepadInputState()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        checkGamepadConnection()

        setContent {
            MyApplicationTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = Color(0xFF0F141F)
                ) {
                    CreedUnityMainApp(viewModel)
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        checkGamepadConnection()
    }

    private fun checkGamepadConnection() {
        val (connected, name) = GamepadHandler.isGamepadConnected()
        internalGamepadState = internalGamepadState.copy(
            isControllerConnected = connected,
            controllerName = if (connected) name else ""
        )
        viewModel.updateGamepadState(internalGamepadState)
    }

    // GAMEPAD ANALOG STICK & TRIGGER MOTION EVENTS
    override fun onGenericMotionEvent(event: MotionEvent?): Boolean {
        if (event == null) return super.onGenericMotionEvent(event)

        val stickX = GamepadHandler.applyDeadzone(event.getAxisValue(MotionEvent.AXIS_X))
        val stickY = GamepadHandler.applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Y))
        val rightStickX = GamepadHandler.applyDeadzone(event.getAxisValue(MotionEvent.AXIS_Z))
        val rightStickY = GamepadHandler.applyDeadzone(event.getAxisValue(MotionEvent.AXIS_RZ))
        val rTrigger = event.getAxisValue(MotionEvent.AXIS_RTRIGGER).coerceAtLeast(0f)
        val lTrigger = event.getAxisValue(MotionEvent.AXIS_LTRIGGER).coerceAtLeast(0f)

        internalGamepadState = internalGamepadState.copy(
            isControllerConnected = true,
            stickX = stickX,
            stickY = stickY,
            rightStickX = rightStickX,
            rightStickY = rightStickY,
            btnR2 = rTrigger,
            btnL2 = lTrigger
        )
        viewModel.updateGamepadState(internalGamepadState)
        return true
    }

    // GAMEPAD BUTTON PRESS EVENTS
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        var handled = false
        internalGamepadState = when (keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> {
                handled = true
                internalGamepadState.copy(btnA = true)
            }
            KeyEvent.KEYCODE_BUTTON_B -> {
                handled = true
                internalGamepadState.copy(btnB = true)
            }
            KeyEvent.KEYCODE_BUTTON_X -> {
                handled = true
                internalGamepadState.copy(btnX = true)
            }
            KeyEvent.KEYCODE_BUTTON_Y -> {
                handled = true
                internalGamepadState.copy(btnY = true)
            }
            KeyEvent.KEYCODE_BUTTON_R1 -> {
                handled = true
                internalGamepadState.copy(btnR1 = true)
            }
            KeyEvent.KEYCODE_BUTTON_L1 -> {
                handled = true
                internalGamepadState.copy(btnL1 = true)
            }
            KeyEvent.KEYCODE_BUTTON_START -> {
                handled = true
                viewModel.setScreen(
                    if (viewModel.currentScreen.value == ScreenTab.GAMEPLAY) ScreenTab.FACTIONS else ScreenTab.GAMEPLAY
                )
                internalGamepadState.copy(btnStart = true)
            }
            else -> internalGamepadState
        }

        if (handled) {
            internalGamepadState = internalGamepadState.copy(isControllerConnected = true)
            viewModel.updateGamepadState(internalGamepadState)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent?): Boolean {
        var handled = false
        internalGamepadState = when (keyCode) {
            KeyEvent.KEYCODE_BUTTON_A -> {
                handled = true
                internalGamepadState.copy(btnA = false)
            }
            KeyEvent.KEYCODE_BUTTON_B -> {
                handled = true
                internalGamepadState.copy(btnB = false)
            }
            KeyEvent.KEYCODE_BUTTON_X -> {
                handled = true
                internalGamepadState.copy(btnX = false)
            }
            KeyEvent.KEYCODE_BUTTON_Y -> {
                handled = true
                internalGamepadState.copy(btnY = false)
            }
            KeyEvent.KEYCODE_BUTTON_R1 -> {
                handled = true
                internalGamepadState.copy(btnR1 = false)
            }
            KeyEvent.KEYCODE_BUTTON_L1 -> {
                handled = true
                internalGamepadState.copy(btnL1 = false)
            }
            KeyEvent.KEYCODE_BUTTON_START -> {
                handled = true
                internalGamepadState.copy(btnStart = false)
            }
            else -> internalGamepadState
        }

        if (handled) {
            viewModel.updateGamepadState(internalGamepadState)
            return true
        }
        return super.onKeyUp(keyCode, event)
    }
}

@Composable
fun CreedUnityMainApp(viewModel: GameViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val gameSave by viewModel.gameSave.collectAsStateWithLifecycle()
    val missions by viewModel.missions.collectAsStateWithLifecycle()
    val factions by viewModel.factions.collectAsStateWithLifecycle()
    val vendorItems by viewModel.vendorItems.collectAsStateWithLifecycle()
    val selectedFactionVendor by viewModel.selectedFactionForVendor.collectAsStateWithLifecycle()
    val gamepadState by viewModel.gamepadState.collectAsStateWithLifecycle()
    val factionNotification by viewModel.latestFactionNotification.collectAsStateWithLifecycle()

    var touchMoveX by remember { mutableFloatStateOf(0f) }
    var touchMoveY by remember { mutableFloatStateOf(0f) }
    var isSprintPressed by remember { mutableStateOf(false) }
    var isCrouchPressed by remember { mutableStateOf(false) }
    var renderTick by remember { mutableFloatStateOf(0f) }

    // 60 FPS Game Loop Ticker
    LaunchedEffect(Unit) {
        var lastTimeNanos = 0L
        while (true) {
            withFrameNanos { frameTimeNanos ->
                if (lastTimeNanos != 0L) {
                    val dt = ((frameTimeNanos - lastTimeNanos) / 1_000_000_000f).coerceIn(0.001f, 0.05f)
                    if (currentScreen == ScreenTab.GAMEPLAY) {
                        viewModel.gameEngine.update(
                            dt = dt,
                            moveX = touchMoveX,
                            moveY = touchMoveY,
                            isSprintPressed = isSprintPressed,
                            isCrouchPressed = isCrouchPressed,
                            gamepadState = gamepadState
                        )
                        renderTick = frameTimeNanos.toFloat()
                    }
                }
                lastTimeNanos = frameTimeNanos
            }
        }
    }

    when (currentScreen) {
        ScreenTab.GAMEPLAY -> {
            Box(modifier = Modifier.fillMaxSize()) {
                GameCanvas(
                    gameEngine = viewModel.gameEngine,
                    renderTick = renderTick
                )
                GameHud(
                    gameEngine = viewModel.gameEngine,
                    livres = (gameSave?.livres ?: 450) + viewModel.gameEngine.player.livresEarnedThisRun,
                    syncPoints = gameSave?.syncPoints ?: 120,
                    gamepadState = gamepadState,
                    factionNotification = factionNotification,
                    onDismissNotification = { viewModel.dismissNotification() },
                    onMoveChange = { x, y ->
                        touchMoveX = x
                        touchMoveY = y
                    },
                    onSprintChange = { isSprintPressed = it },
                    onCrouchChange = { isCrouchPressed = it },
                    onNavigateTab = { tab -> viewModel.setScreen(tab) }
                )
            }
        }

        ScreenTab.FACTIONS -> {
            BackHandler { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            FactionsScreen(
                factions = factions,
                onBack = { viewModel.setScreen(ScreenTab.GAMEPLAY) },
                onOpenVendor = { factionId -> viewModel.openVendorForFaction(factionId) }
            )
        }

        ScreenTab.VENDOR -> {
            BackHandler { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            FactionVendorScreen(
                factions = factions,
                vendorItems = vendorItems,
                initialFactionId = selectedFactionVendor,
                playerLivres = (gameSave?.livres ?: 450) + viewModel.gameEngine.player.livresEarnedThisRun,
                onPurchaseItem = { item, callback -> viewModel.purchaseItem(item, callback) },
                onBack = { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            )
        }

        ScreenTab.MISSIONS -> {
            BackHandler { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            MissionsScreen(
                missions = missions,
                activeMissionId = viewModel.gameEngine.activeMissionId,
                onSelectMission = { mission -> viewModel.startMission(mission) },
                onBack = { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            )
        }

        ScreenTab.SETTINGS -> {
            BackHandler { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            SettingsScreen(
                currentPreset = gameSave?.graphicsPreset ?: "UE5_CINEMATIC",
                gamepadState = gamepadState,
                onSetPreset = { preset -> viewModel.updateGraphicsPreset(preset) },
                onBack = { viewModel.setScreen(ScreenTab.GAMEPLAY) }
            )
        }
    }
}
