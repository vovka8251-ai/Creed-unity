package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Offset
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.RemoveRedEye
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SportsKabaddi
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.controller.GamepadInputState
import com.example.game.engine.GadgetType
import com.example.game.engine.GameEngine
import com.example.game.engine.PlayerPosture
import com.example.ui.viewmodel.FactionNotification
import com.example.ui.viewmodel.ScreenTab
import kotlin.math.roundToInt
import kotlin.math.sqrt

@Composable
fun GameHud(
    gameEngine: GameEngine,
    livres: Int,
    syncPoints: Int,
    gamepadState: GamepadInputState,
    factionNotification: FactionNotification?,
    onDismissNotification: () -> Unit,
    onMoveChange: (Float, Float) -> Unit,
    onSprintChange: (Boolean) -> Unit,
    onCrouchChange: (Boolean) -> Unit,
    onNavigateTab: (ScreenTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        // TOP STATUS BAR & NOTIFICATIONS
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .padding(horizontal = 16.dp, vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Screen Navigation Quick Bar
            Row(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color(0xDD121722))
                    .border(1.dp, Color(0x443F4D6B), RoundedCornerShape(20.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NavTabPill("Paris 1789", isSelected = true) { onNavigateTab(ScreenTab.GAMEPLAY) }
                NavTabPill("Factions", isSelected = false) { onNavigateTab(ScreenTab.FACTIONS) }
                NavTabPill("Vendors", isSelected = false) { onNavigateTab(ScreenTab.VENDOR) }
                NavTabPill("Contracts", isSelected = false) { onNavigateTab(ScreenTab.MISSIONS) }
                NavTabPill("Settings", isSelected = false) { onNavigateTab(ScreenTab.SETTINGS) }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Player Vital & Mission Status Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Arno Status Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC161B26)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Health Bar
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "ARNO",
                                    color = Color.White,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "${gameEngine.player.health.toInt()} HP",
                                    color = Color(0xFF81C784),
                                    fontSize = 11.sp
                                )
                            }
                            Box(
                                modifier = Modifier
                                    .width(90.dp)
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp))
                                    .background(Color(0xFF333A48))
                            ) {
                                val healthFraction = (gameEngine.player.health / gameEngine.player.maxHealth).coerceIn(0f, 1f)
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth(healthFraction)
                                        .height(6.dp)
                                        .background(if (healthFraction > 0.35f) Color(0xFF4CAF50) else Color(0xFFE53935))
                                )
                            }
                        }

                        // Posture Indicator
                        val postureText = when (gameEngine.player.posture) {
                            PlayerPosture.IN_HAYSTACK -> "Haystack Cover"
                            PlayerPosture.BLENDED_IN_CROWD -> "Crowd Blended"
                            PlayerPosture.CROUCH_STEALTH -> "Crouch Stealth"
                            PlayerPosture.ROOFTOP_PERCH -> "Rooftop (Z=${gameEngine.player.elevationZ})"
                            PlayerPosture.SPRINT_PARKOUR -> "Parkour Sprint"
                            else -> "Normal Stride"
                        }
                        Text(
                            text = postureText,
                            color = if (gameEngine.player.isBlended) Color(0xFF40C4FF) else Color(0xFFBAC5D5),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Mission Tracker Card
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xCC161B26)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                        Text(
                            text = "🎯 ${gameEngine.activeMissionTitle}",
                            color = Color(0xFFFFD54F),
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Target: ${gameEngine.activeTargetName} (${gameEngine.activeDistrict})",
                            color = Color(0xFFECEFF1),
                            fontSize = 10.sp
                        )
                    }
                }

                // Currency & Controller Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = Color(0xCC231E12),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x66FFD700))
                    ) {
                        Text(
                            text = "$livres F",
                            color = Color(0xFFFFD700),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }

                    if (gamepadState.isControllerConnected) {
                        Surface(
                            color = Color(0xDD1B5E20),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "🎮 ${gamepadState.controllerName.take(14)}",
                                color = Color.White,
                                fontSize = 10.sp,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }

            // Real-Time Faction Notification Banner
            AnimatedVisibility(
                visible = factionNotification != null,
                enter = slideInVertically() + fadeIn(),
                exit = slideOutVertically() + fadeOut()
            ) {
                factionNotification?.let { notif ->
                    LaunchedEffect(notif) {
                        kotlinx.coroutines.delay(4000)
                        onDismissNotification()
                    }
                    val sign = if (notif.delta >= 0) "+${notif.delta}" else "${notif.delta}"
                    val badgeColor = if (notif.delta >= 0) Color(0xFF2E7D32) else Color(0xFFC62828)

                    Surface(
                        color = Color(0xF0182030),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, badgeColor),
                        modifier = Modifier
                            .padding(top = 6.dp)
                            .testTag("faction_notification_banner")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "$sign ${notif.factionName}",
                                color = if (notif.delta >= 0) Color(0xFF81C784) else Color(0xFFEF5350),
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "• ${notif.reason}",
                                color = Color.White,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }

            // In-game Banner (Air assassination, synchronized, alert)
            gameEngine.bannerMessage?.let { msg ->
                Surface(
                    color = Color(0xEE1E2433),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4A5568)),
                    modifier = Modifier.padding(top = 4.dp)
                ) {
                    Text(
                        text = msg,
                        color = Color(0xFFFFEE58),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }
        }

        // BOTTOM-LEFT: Virtual Analog Touch Joystick
        VirtualJoystick(
            onMove = onMoveChange,
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 28.dp, bottom = 24.dp)
        )

        // Quick Gadgets & Public Acts Bar (Above Joystick)
        Row(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 24.dp, bottom = 165.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color(0xDD121622))
                .border(1.dp, Color(0x443E4B66), RoundedCornerShape(24.dp))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Smoke Bomb
            ActionButtonSmall(
                label = "Smoke",
                count = gameEngine.player.smokeBombs,
                isSelected = gameEngine.player.selectedGadget == GadgetType.SMOKE_BOMB,
                testTag = "gadget_smoke_button"
            ) {
                gameEngine.player.selectedGadget = GadgetType.SMOKE_BOMB
                gameEngine.useGadget()
            }

            // Phantom Blade
            ActionButtonSmall(
                label = "Phantom",
                count = gameEngine.player.phantomBlades,
                isSelected = gameEngine.player.selectedGadget == GadgetType.PHANTOM_BLADE,
                testTag = "gadget_phantom_button"
            ) {
                gameEngine.player.selectedGadget = GadgetType.PHANTOM_BLADE
                gameEngine.useGadget()
            }

            // Whistle
            ActionButtonSmall(
                label = "Whistle",
                isSelected = gameEngine.player.selectedGadget == GadgetType.WHISTLE,
                testTag = "gadget_whistle_button"
            ) {
                gameEngine.whistle()
            }

            // PUBLIC ACT: Toss Livres / Incite Crowd Riot
            ActionButtonSmall(
                label = "Incite Riot",
                iconText = "30F",
                highlightColor = Color(0xFFFFD700),
                testTag = "public_act_riot_button"
            ) {
                gameEngine.tossCoinsAndInciteRiot()
            }

            // Contextual: Liberate Prisoners (Public Act)
            if (gameEngine.canLiberateCage != null) {
                ActionButtonSmall(
                    label = "Liberate!",
                    highlightColor = Color(0xFF00E676),
                    testTag = "public_act_liberate_button"
                ) {
                    gameEngine.liberatePrisoners()
                }
            }

            // Contextual: Synchronize Viewpoint
            if (gameEngine.canSynchronizeViewpoint != null) {
                ActionButtonSmall(
                    label = "Sync Spire",
                    highlightColor = Color(0xFF00B0FF),
                    testTag = "sync_viewpoint_button"
                ) {
                    gameEngine.synchronizeViewpoint()
                }
            }

            // Contextual: Loot Chest
            if (gameEngine.canLootChest != null) {
                ActionButtonSmall(
                    label = "Loot Chest",
                    highlightColor = Color(0xFFFFB300),
                    testTag = "loot_chest_button"
                ) {
                    gameEngine.lootChest()
                }
            }

            // Contextual: Hide in Haystack
            if (gameEngine.canHideInHaystack != null) {
                ActionButtonSmall(
                    label = if (gameEngine.player.isHiddenInHay) "Exit Hay" else "Hide Hay",
                    highlightColor = Color(0xFFFFD54F),
                    testTag = "haystack_hide_button"
                ) {
                    gameEngine.toggleHaystackHide()
                }
            }
        }

        // BOTTOM-RIGHT: Action Buttons Diamond
        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 24.dp, bottom = 20.dp)
                .size(190.dp)
        ) {
            // SPRINT / PARKOUR (Top button of diamond)
            HoldButton(
                text = "SPRINT",
                hint = if (gamepadState.isControllerConnected) "[RT / A]" else "",
                onHoldChanged = onSprintChange,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .size(62.dp)
                    .testTag("parkour_sprint_button")
            )

            // EAGLE VISION (Left button of diamond)
            IconButton(
                onClick = { gameEngine.toggleEagleVision() },
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(if (gameEngine.player.isEagleVisionActive) Color(0xFF00B0FF) else Color(0xDD1B2232))
                    .border(2.dp, Color(0xFF4FC3F7), CircleShape)
                    .testTag("eagle_vision_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.Visibility,
                        contentDescription = "Eagle Vision",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                    Text(
                        text = if (gamepadState.isControllerConnected) "[Y]" else "EAGLE",
                        fontSize = 9.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // CROUCH / STEALTH (Right button of diamond)
            HoldButton(
                text = "STEALTH",
                hint = if (gamepadState.isControllerConnected) "[B]" else "",
                onHoldChanged = onCrouchChange,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .size(56.dp)
                    .testTag("crouch_stealth_button")
            )

            // ASSASSINATE / ATTACK (Bottom button - Largest & Highlighted!)
            val target = gameEngine.canAssassinateTarget
            val isAir = gameEngine.isAirAssassinationPossible
            val actionLabel = when {
                isAir -> "AIR KILL"
                target != null -> "ASSASSINATE"
                else -> "ATTACK"
            }
            val buttonColor = when {
                isAir -> Color(0xFFD50000)
                target != null -> Color(0xFFC2185B)
                else -> Color(0xDD242E42)
            }

            IconButton(
                onClick = { gameEngine.triggerAssassination() },
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .size(70.dp)
                    .clip(CircleShape)
                    .background(buttonColor)
                    .border(2.5.dp, if (target != null) Color(0xFFFF5252) else Color(0xFF5C6BC0), CircleShape)
                    .testTag("assassinate_button")
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Default.SportsKabaddi,
                        contentDescription = "Assassinate",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (gamepadState.isControllerConnected) "[X] $actionLabel" else actionLabel,
                        fontSize = 9.sp,
                        color = Color.White,
                        fontWeight = FontWeight.Black
                    )
                }
            }
        }
    }
}

@Composable
private fun NavTabPill(label: String, isSelected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = if (isSelected) Color(0xFF2B5CB8) else Color.Transparent,
        shape = RoundedCornerShape(16.dp)
    ) {
        Text(
            text = label,
            color = if (isSelected) Color.White else Color(0xFFB0BEC5),
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun ActionButtonSmall(
    label: String,
    count: Int? = null,
    isSelected: Boolean = false,
    highlightColor: Color? = null,
    iconText: String? = null,
    testTag: String,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        color = when {
            highlightColor != null -> highlightColor.copy(alpha = 0.25f)
            isSelected -> Color(0xFF335C99)
            else -> Color(0xDD202738)
        },
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            highlightColor ?: if (isSelected) Color(0xFF4FC3F7) else Color(0x444A5A7A)
        ),
        modifier = Modifier.testTag(testTag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Text(
                text = label,
                color = highlightColor ?: Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            count?.let {
                Text(
                    text = "($it)",
                    color = Color(0xFF81D4FA),
                    fontSize = 10.sp
                )
            }
            iconText?.let {
                Text(
                    text = it,
                    color = Color(0xFFFFD700),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

@Composable
private fun HoldButton(
    text: String,
    hint: String,
    onHoldChanged: (Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    var isPressed by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(if (isPressed) Color(0xFF2E7D32) else Color(0xDD1E2638))
            .border(2.dp, if (isPressed) Color(0xFF81C784) else Color(0xFF4A5568), CircleShape)
            .pointerInput(Unit) {
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent()
                        val down = event.changes.any { it.pressed }
                        if (down != isPressed) {
                            isPressed = down
                            onHoldChanged(down)
                        }
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = text,
                color = Color.White,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
            if (hint.isNotEmpty()) {
                Text(
                    text = hint,
                    color = Color(0xFFA5D6A7),
                    fontSize = 8.sp
                )
            }
        }
    }
}

@Composable
private fun VirtualJoystick(
    onMove: (Float, Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }
    val maxRadius = 55f

    Box(
        modifier = modifier
            .size(130.dp)
            .clip(CircleShape)
            .background(Color(0x77101522))
            .border(2.dp, Color(0x553C4D6D), CircleShape)
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { },
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        onMove(0f, 0f)
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val newOffset = knobOffset + dragAmount
                        val dist = sqrt(newOffset.x * newOffset.x + newOffset.y * newOffset.y)
                        knobOffset = if (dist > maxRadius) {
                            Offset(
                                (newOffset.x / dist) * maxRadius,
                                (newOffset.y / dist) * maxRadius
                            )
                        } else {
                            newOffset
                        }
                        val normX = (knobOffset.x / maxRadius).coerceIn(-1f, 1f)
                        val normY = (knobOffset.y / maxRadius).coerceIn(-1f, 1f)
                        onMove(normX, normY)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // Inner Crosshair ring
        Box(
            modifier = Modifier
                .size(45.dp)
                .border(1.dp, Color(0x33FFFFFF), CircleShape)
        )
        // Draggable Knob
        Box(
            modifier = Modifier
                .offset { IntOffset(knobOffset.x.roundToInt(), knobOffset.y.roundToInt()) }
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(0xDD2A599B))
                .border(2.dp, Color(0xFF64B5F6), CircleShape)
        )
    }
}
