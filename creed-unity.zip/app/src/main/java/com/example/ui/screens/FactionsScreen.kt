package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Store
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FactionEntity
import com.example.data.model.FactionTier
import com.example.data.model.FactionType

@Composable
fun FactionsScreen(
    factions: List<FactionEntity>,
    onBack: () -> Unit,
    onOpenVendor: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F141F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                            .testTag("factions_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "PARIS FACTIONS & REPUTATION",
                            color = Color.White,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Standing shapes enemy alertness, unlocked vendors, and street alliances",
                            color = Color(0xFF90A4AE),
                            fontSize = 11.sp
                        )
                    }
                }

                Surface(
                    color = Color(0x224FC3F7),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4FC3F7))
                ) {
                    Text(
                        text = "Revolutionary Year 1789",
                        color = Color(0xFF81D4FA),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Standing Rule Guide Banner
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF171F2E)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ReputationTierPill("Hated (-100..-31)", Color(0xFFE53935), "Attacks on sight")
                    ReputationTierPill("Suspicious (-30..9)", Color(0xFFFB8C00), "Fast detection")
                    ReputationTierPill("Neutral (10..39)", Color(0xFF90A4AE), "Normal patrols")
                    ReputationTierPill("Friendly (40..74)", Color(0xFF42A5F5), "Vendor open")
                    ReputationTierPill("Allied (75..100)", Color(0xFFFFD700), "Street support")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Factions List
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                items(factions, key = { it.factionId }) { faction ->
                    FactionCard(
                        faction = faction,
                        onOpenVendor = { onOpenVendor(faction.factionId) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ReputationTierPill(name: String, color: Color, rule: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = name, color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(text = rule, color = Color(0xFFB0BEC5), fontSize = 8.sp)
    }
}

@Composable
private fun FactionCard(
    faction: FactionEntity,
    onOpenVendor: () -> Unit
) {
    val tier = FactionTier.getTier(faction.standing)
    val facType = FactionType.fromId(faction.factionId)
    val tierColor = when (tier) {
        FactionTier.HATED -> Color(0xFFE53935)
        FactionTier.SUSPICIOUS -> Color(0xFFFB8C00)
        FactionTier.NEUTRAL -> Color(0xFF90A4AE)
        FactionTier.FRIENDLY -> Color(0xFF42A5F5)
        FactionTier.ALLIED -> Color(0xFFFFD700)
    }

    val isVendorUnlocked = faction.standing >= 20

    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFF151C2A)),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, tierColor.copy(alpha = 0.5f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("faction_card_${faction.factionId}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Row: Name, French Title, Tier Badge
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(Color(facType.colorHex).copy(alpha = 0.25f))
                            .border(1.5.dp, Color(facType.colorHex), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Shield,
                            contentDescription = null,
                            tint = Color(facType.colorHex),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = faction.name,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = faction.frenchTitle,
                            color = Color(0xFF90A4AE),
                            fontSize = 11.sp
                        )
                    }
                }

                // Standing & Tier Pill
                Surface(
                    color = tierColor.copy(alpha = 0.18f),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, tierColor)
                ) {
                    Text(
                        text = "${tier.displayName} (${if (faction.standing > 0) "+${faction.standing}" else faction.standing})",
                        color = tierColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Standing Progress Bar (-100 to 100 mapped to 0..1)
            val standingFraction = ((faction.standing + 100f) / 200f).coerceIn(0f, 1f)
            LinearProgressIndicator(
                progress = { standingFraction },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(6.dp)
                    .clip(RoundedCornerShape(3.dp)),
                color = tierColor,
                trackColor = Color(0xFF263238),
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = faction.description,
                color = Color(0xFFCFD8DC),
                fontSize = 11.sp,
                lineHeight = 15.sp
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Bonus and Headquarter Details
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text(text = "Headquarters:", color = Color(0xFF78909C), fontSize = 10.sp)
                    Text(text = faction.headquarters, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
                Column {
                    Text(text = "Active Bonus:", color = Color(0xFF78909C), fontSize = 10.sp)
                    Text(text = faction.activeBonus, color = Color(0xFF81C784), fontSize = 11.sp, fontWeight = FontWeight.Medium)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Vendor Access Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = if (isVendorUnlocked) Icons.Default.LockOpen else Icons.Default.Lock,
                        contentDescription = null,
                        tint = if (isVendorUnlocked) Color(0xFF4CAF50) else Color(0xFFE53935),
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isVendorUnlocked) "Vendor: ${faction.vendorName}" else "Vendor Restricted (Requires Neutral+)",
                        color = if (isVendorUnlocked) Color.White else Color(0xFFEF9A9A),
                        fontSize = 11.sp
                    )
                }

                Button(
                    onClick = onOpenVendor,
                    enabled = isVendorUnlocked,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF254B8C),
                        disabledContainerColor = Color(0xFF1E2430)
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("vendor_button_${faction.factionId}")
                ) {
                    Icon(imageVector = Icons.Default.Store, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Visit Vendor", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
