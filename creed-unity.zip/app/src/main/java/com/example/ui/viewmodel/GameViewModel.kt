package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Vibrator
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.db.GameDatabase
import com.example.data.model.FactionEntity
import com.example.data.model.FactionTier
import com.example.data.model.FactionVendorItem
import com.example.data.model.GameSaveEntity
import com.example.data.model.MissionEntity
import com.example.data.repository.GameRepository
import com.example.game.audio.GameAudioEngine
import com.example.game.controller.GamepadInputState
import com.example.game.engine.GameEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class ScreenTab {
    GAMEPLAY,
    FACTIONS,
    VENDOR,
    MISSIONS,
    SETTINGS
}

data class FactionNotification(
    val factionId: String,
    val factionName: String,
    val delta: Int,
    val reason: String,
    val timestamp: Long = System.currentTimeMillis()
)

class GameViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: GameRepository
    val audioEngine = GameAudioEngine()
    private val vibrator: Vibrator? = application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator

    val gameEngine: GameEngine

    val gameSave: StateFlow<GameSaveEntity?>
    val missions: StateFlow<List<MissionEntity>>
    val factions: StateFlow<List<FactionEntity>>
    val vendorItems: StateFlow<List<FactionVendorItem>>

    private val _currentScreen = MutableStateFlow(ScreenTab.GAMEPLAY)
    val currentScreen: StateFlow<ScreenTab> = _currentScreen.asStateFlow()

    private val _selectedFactionForVendor = MutableStateFlow<String>("assassins")
    val selectedFactionForVendor: StateFlow<String> = _selectedFactionForVendor.asStateFlow()

    private val _gamepadState = MutableStateFlow(GamepadInputState())
    val gamepadState: StateFlow<GamepadInputState> = _gamepadState.asStateFlow()

    private val _latestFactionNotification = MutableStateFlow<FactionNotification?>(null)
    val latestFactionNotification: StateFlow<FactionNotification?> = _latestFactionNotification.asStateFlow()

    init {
        val db = GameDatabase.getInstance(application)
        repository = GameRepository(db.gameDao())

        gameSave = repository.gameSaveFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            GameSaveEntity()
        )

        missions = repository.allMissionsFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        factions = repository.allFactionsFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        vendorItems = repository.allVendorItemsFlow.stateIn(
            viewModelScope,
            SharingStarted.WhileSubscribed(5000),
            emptyList()
        )

        gameEngine = GameEngine(
            audioEngine = audioEngine,
            vibrator = vibrator,
            onMissionComplete = { missionId, stealthBonus, livres, sync ->
                viewModelScope.launch {
                    repository.completeMission(missionId, stealthBonus, livres, sync)
                }
            },
            onViewpointSynced = { _ ->
                viewModelScope.launch {
                    repository.recordViewpointSync()
                }
            },
            onStealthKillAchieved = {
                viewModelScope.launch {
                    repository.recordStealthKill()
                }
            }
        )

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            repository.ensureInitialized()
        }

        // Wire real-time faction standing changes from the simulation engine
        gameEngine.onFactionStandingChanged = { factionId, delta, reason ->
            viewModelScope.launch {
                repository.adjustStanding(factionId, delta)
                val currentFac = factions.value.find { it.factionId == factionId }
                val facName = currentFac?.name ?: factionId.replaceFirstChar { it.uppercase() }
                _latestFactionNotification.value = FactionNotification(
                    factionId = factionId,
                    factionName = facName,
                    delta = delta,
                    reason = reason
                )
            }
        }
    }

    fun setScreen(tab: ScreenTab) {
        _currentScreen.value = tab
    }

    fun openVendorForFaction(factionId: String) {
        _selectedFactionForVendor.value = factionId
        _currentScreen.value = ScreenTab.VENDOR
    }

    fun updateGamepadState(state: GamepadInputState) {
        _gamepadState.value = state
    }

    fun startMission(mission: MissionEntity) {
        gameEngine.loadMission(
            missionId = mission.missionId,
            title = mission.title,
            target = mission.targetName,
            district = mission.district
        )
        _currentScreen.value = ScreenTab.GAMEPLAY
    }

    fun purchaseItem(item: FactionVendorItem, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val currentFaction = factions.value.find { it.factionId == item.factionId }
            val currentStanding = currentFaction?.standing ?: 0

            if (currentStanding < item.requiredStanding) {
                val reqTier = FactionTier.getTier(item.requiredStanding).displayName
                onResult(false, "Reputation too low! Requires $reqTier (${item.requiredStanding} standing).")
                return@launch
            }

            val currentLivres = gameSave.value?.livres ?: 0
            if (currentLivres < item.costLivres) {
                onResult(false, "Not enough Livres! Requires ${item.costLivres} F.")
                return@launch
            }

            val success = repository.purchaseVendorItem(item)
            if (success) {
                audioEngine.playHiddenBlade()
                onResult(true, "Purchased ${item.name}! Added to arsenal.")
            } else {
                onResult(false, "Transaction failed.")
            }
        }
    }

    fun updateGraphicsPreset(preset: String) {
        viewModelScope.launch {
            repository.setGraphicsPreset(preset)
        }
    }

    fun dismissNotification() {
        _latestFactionNotification.value = null
    }
}
