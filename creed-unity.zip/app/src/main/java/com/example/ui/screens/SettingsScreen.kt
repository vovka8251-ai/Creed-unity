package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material.icons.filled.VideogameAsset
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.game.controller.GamepadInputState

@Composable
fun SettingsScreen(
    currentPreset: String,
    gamepadState: GamepadInputState,
    onSetPreset: (String) -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    var vibrationEnabled by remember { mutableStateOf(true) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0F141F))
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0x33FFFFFF))
                            .testTag("settings_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "GRAPHICS & GAMEPAD CONTROLS",
                            color = Color.White,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.ExtraBold
                        )
                        Text(
                            text = "Unreal Engine 5 Graphics fidelity & external controller settings",
                            color = Color(0xFF90A4AE),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize()
            ) {
                // Section: External Gamepad Controller Support
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161F2E)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.SportsEsports,
                                        contentDescription = null,
                                        tint = if (gamepadState.isControllerConnected) Color(0xFF00E676) else Color(0xFF90A4AE),
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = "External Controller Status",
                                            color = Color.White,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = if (gamepadState.isControllerConnected)
                                                "Active: ${gamepadState.controllerName}"
                                            else
                                                "Bluetooth / USB Gamepad (Xbox, DualSense, Kishi)",
                                            color = if (gamepadState.isControllerConnected) Color(0xFF81C784) else Color(0xFFB0BEC5),
                                            fontSize = 11.sp
                                        )
                                    }
                                }

                                Surface(
                                    color = if (gamepadState.isControllerConnected) Color(0x3300E676) else Color(0x22FFFFFF),
                                    shape = RoundedCornerShape(10.dp),
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (gamepadState.isControllerConnected) Color(0xFF00E676) else Color(0x44FFFFFF)
                                    )
                                ) {
                                    Text(
                                        text = if (gamepadState.isControllerConnected) "CONNECTED" else "AUTO-DETECT",
                                        color = if (gamepadState.isControllerConnected) Color(0xFF00E676) else Color(0xFFCFD8DC),
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Controller Button Mapping Grid
                            Text(
                                text = "Gamepad Mapping Scheme:",
                                color = Color(0xFFB0BEC5),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                GamepadKeyLabel("[Left Stick]", "Movement")
                                GamepadKeyLabel("[X / Square]", "Assassinate")
                                GamepadKeyLabel("[A / Cross]", "Parkour / Sprint")
                                GamepadKeyLabel("[B / Circle]", "Crouch / Stealth")
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                GamepadKeyLabel("[Y / Triangle]", "Eagle Vision")
                                GamepadKeyLabel("[R1 / RB]", "Quick Gadget")
                                GamepadKeyLabel("[L1 / LB]", "Whistle")
                                GamepadKeyLabel("[RT / R2]", "High Profile")
                            }
                        }
                    }
                }

                // Section: Unreal Engine 5 Visual Presets
                item {
                    Text(
                        text = "Unreal Engine 5 Graphics Quality",
                        color = Color.White,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                item {
                    GraphicsPresetCard(
                        title = "UE5 CINEMATIC (Max Graphics)",
                        subtitle = "Volumetric dusk fog, dynamic Paris embers, chiaroscuro lighting, full Notre-Dame geometry & crowds",
                        isSelected = currentPreset == "UE5_CINEMATIC",
                        onSelect = { onSetPreset("UE5_CINEMATIC") }
                    )
                }

                item {
                    GraphicsPresetCard(
                        title = "HIGH FIDELITY",
                        subtitle = "Atmospheric shaders, dynamic guard detection cones, standard crowd density",
                        isSelected = currentPreset == "FIDELITY",
                        onSelect = { onSetPreset("FIDELITY") }
                    )
                }

                item {
                    GraphicsPresetCard(
                        title = "PERFORMANCE (60 FPS Ultra)",
                        subtitle = "Low particle latency, streamlined lighting for maximum battery efficiency",
                        isSelected = currentPreset == "PERFORMANCE",
                        onSelect = { onSetPreset("PERFORMANCE") }
                    )
                }

                // Section: Haptics & Vibration
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF161F2E)),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(imageVector = Icons.Default.Vibration, contentDescription = null, tint = Color(0xFF4FC3F7))
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(text = "Haptic Assassination Feedback", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    Text(text = "Controller & device vibrations on strikes and leap of faith", color = Color(0xFF90A4AE), fontSize = 11.sp)
                                }
                            }
                            Switch(
                                checked = vibrationEnabled,
                                onCheckedChange = { vibrationEnabled = it },
                                colors = SwitchDefaults.colors(checkedThumbColor = Color(0xFF4FC3F7))
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun GamepadKeyLabel(key: String, action: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = key, color = Color(0xFF4FC3F7), fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(text = action, color = Color.White, fontSize = 9.sp)
    }
}

@Composable
private fun GraphicsPresetCard(
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onSelect: () -> Unit
) {
    Card(
        onClick = onSelect,
        colors = CardDefaults.cardColors(
            containerColor = if (isSelected) Color(0xFF1E2E47) else Color(0xFF151C2A)
        ),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (isSelected) Color(0xFF4FC3F7) else Color(0x33455A64)
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(text = title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(4.dp))
                Text(text = subtitle, color = Color(0xFF90A4AE), fontSize = 10.sp, lineHeight = 14.sp)
            }
            if (isSelected) {
                Surface(
                    color = Color(0xFF4FC3F7),
                    shape = CircleShape,
                    modifier = Modifier.size(24.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}
