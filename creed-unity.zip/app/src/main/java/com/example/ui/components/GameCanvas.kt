package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import com.example.game.engine.Building
import com.example.game.engine.CrowdPerson
import com.example.game.engine.GameEngine
import com.example.game.engine.Guard
import com.example.game.engine.GuardState
import com.example.game.engine.GuardType
import com.example.game.engine.Haystack
import com.example.game.engine.LootChest
import com.example.game.engine.Particle
import com.example.game.engine.Player
import com.example.game.engine.PlayerPosture
import com.example.game.engine.PrisonerCage
import com.example.game.engine.SmokeCloud
import com.example.game.engine.Vector2D
import com.example.game.engine.Viewpoint
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun GameCanvas(
    gameEngine: GameEngine,
    renderTick: Float = 0f,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.fillMaxSize()) {
        val tick = renderTick
        val screenCenterX = size.width / 2f
        val screenCenterY = size.height / 2f

        val camX = gameEngine.cameraX
        val camY = gameEngine.cameraY
        val isEagle = gameEngine.player.isEagleVisionActive

        // Background / Street base
        val streetColor = if (isEagle) Color(0xFF0D131F) else Color(0xFF23252E)
        drawRect(streetColor)

        // Draw Cobblestone Street Grid
        drawCobblestoneGrid(screenCenterX - camX, screenCenterY - camY, isEagle)

        // Draw Paris Buildings & Notre Dame
        for (b in gameEngine.buildings) {
            drawBuilding(b, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Haystacks
        for (h in gameEngine.haystacks) {
            drawHaystack(h, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Prisoner Cages (Public Act)
        for (cage in gameEngine.prisonerCages) {
            drawPrisonerCage(cage, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Loot Chests
        for (c in gameEngine.lootChests) {
            drawLootChest(c, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Viewpoints
        for (v in gameEngine.viewpoints) {
            drawViewpoint(v, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Revolutionary Crowds
        for (p in gameEngine.crowds) {
            drawCrowdPerson(p, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Guards & Vision Cones
        for (g in gameEngine.guards) {
            drawGuard(g, screenCenterX - camX, screenCenterY - camY, isEagle)
        }

        // Draw Player (Arno Dorian)
        drawPlayer(gameEngine.player, screenCenterX - camX, screenCenterY - camY, isEagle)

        // Draw Smoke Clouds
        for (s in gameEngine.smokeClouds) {
            drawSmokeCloud(s, screenCenterX - camX, screenCenterY - camY)
        }

        // Draw Particles (Embers / Blood / Sparks)
        for (part in gameEngine.particles) {
            drawParticle(part, screenCenterX - camX, screenCenterY - camY)
        }

        // UE5 Lighting Vignette & Eagle Vision Matrix Scanlines
        drawAtmosphericPostProcessing(isEagle)
    }
}

private fun DrawScope.drawCobblestoneGrid(offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val step = 120f
    val startX = (offsetX % step) - step
    val startY = (offsetY % step) - step
    val lineColor = if (isEagle) Color(0x153A659B) else Color(0x22181A22)

    var x = startX
    while (x < size.width + step) {
        drawLine(lineColor, Offset(x, 0f), Offset(x, size.height), strokeWidth = 1.5f)
        x += step
    }
    var y = startY
    while (y < size.height + step) {
        drawLine(lineColor, Offset(0f, y), Offset(size.width, y), strokeWidth = 1.5f)
        y += step
    }
}

private fun DrawScope.drawBuilding(b: Building, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val left = b.x + offsetX
    val top = b.y + offsetY

    // If completely off-screen, skip
    if (left + b.width < 0 || left > size.width || top + b.height < 0 || top > size.height) return

    val baseColor = if (isEagle) {
        Color(0xFF141E2F)
    } else {
        Color(b.colorHex)
    }

    // Building Roof & Shadow
    drawRect(
        color = Color(0x77000000),
        topLeft = Offset(left + 8f, top + 12f),
        size = Size(b.width, b.height)
    )
    drawRect(
        color = baseColor,
        topLeft = Offset(left, top),
        size = Size(b.width, b.height)
    )

    // Roof details / Mansard borders
    val borderColor = if (isEagle) Color(0x444A7EC0) else Color(0xFF5A5262)
    drawRect(
        color = borderColor,
        topLeft = Offset(left, top),
        size = Size(b.width, b.height),
        style = Stroke(width = 3f)
    )

    if (b.isNotreDame) {
        // Gothic Rose Window pattern & twin tower crenellations
        val centerX = left + b.width / 2f
        val centerY = top + b.height / 2f
        val roseColor = if (isEagle) Color(0x8800FFFF) else Color(0xFFE2A43B)

        drawCircle(
            color = roseColor,
            radius = 32f,
            center = Offset(centerX, centerY),
            style = Stroke(width = 4f)
        )
        // Stained glass inner circle
        drawCircle(
            color = if (isEagle) Color(0x3300FFFF) else Color(0x55B83B5E),
            radius = 24f,
            center = Offset(centerX, centerY)
        )
    }
}

private fun DrawScope.drawHaystack(h: Haystack, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = h.pos.x + offsetX
    val cy = h.pos.y + offsetY
    val hayColor = if (isEagle) Color(0xFF00E5FF) else Color(0xFFD4A346)

    drawCircle(
        color = Color(0x44000000),
        radius = h.radius + 3f,
        center = Offset(cx + 4f, cy + 4f)
    )
    drawCircle(
        color = hayColor,
        radius = h.radius,
        center = Offset(cx, cy)
    )
    // Hay strands
    val strandColor = if (isEagle) Color.White else Color(0xFFF7DE89)
    for (i in 0 until 6) {
        val angle = (i * 60) * (PI / 180f)
        val ex = cx + cos(angle).toFloat() * (h.radius * 0.7f)
        val ey = cy + sin(angle).toFloat() * (h.radius * 0.7f)
        drawLine(strandColor, Offset(cx, cy), Offset(ex, ey), strokeWidth = 2f)
    }
}

private fun DrawScope.drawPrisonerCage(cage: PrisonerCage, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = cage.pos.x + offsetX
    val cy = cage.pos.y + offsetY

    val cageColor = if (cage.isLiberated) Color(0xFF2A8B58) else (if (isEagle) Color(0xFF29B6F6) else Color(0xFF8A95A5))
    // Cage box
    drawRect(
        color = Color(0x66000000),
        topLeft = Offset(cx - 24f + 3f, cy - 20f + 3f),
        size = Size(48f, 40f)
    )
    drawRect(
        color = Color(0xFF1F2430),
        topLeft = Offset(cx - 24f, cy - 20f),
        size = Size(48f, 40f)
    )
    drawRect(
        color = cageColor,
        topLeft = Offset(cx - 24f, cy - 20f),
        size = Size(48f, 40f),
        style = Stroke(width = 2.5f)
    )

    // Bars
    if (!cage.isLiberated) {
        for (i in -16..16 step 8) {
            drawLine(cageColor, Offset(cx + i, cy - 20f), Offset(cx + i, cy + 20f), strokeWidth = 2f)
        }
        // Prisoner inside (Red Phrygian cap)
        drawCircle(Color(0xFFC22234), radius = 6f, center = Offset(cx, cy))
    }
}

private fun DrawScope.drawLootChest(c: LootChest, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = c.pos.x + offsetX
    val cy = c.pos.y + offsetY

    val chestColor = if (c.isOpened) Color(0xFF555555) else (if (isEagle) Color(0xFFFFD700) else Color(0xFFC98A2C))
    drawRect(
        color = chestColor,
        topLeft = Offset(cx - 14f, cy - 10f),
        size = Size(28f, 20f)
    )
    // Golden trim
    drawRect(
        color = if (c.isOpened) Color.DarkGray else Color(0xFFFFE066),
        topLeft = Offset(cx - 14f, cy - 10f),
        size = Size(28f, 20f),
        style = Stroke(width = 2f)
    )
}

private fun DrawScope.drawViewpoint(v: Viewpoint, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = v.pos.x + offsetX
    val cy = v.pos.y + offsetY

    val beaconColor = if (v.isSynchronized) Color(0xFF3399FF) else (if (isEagle) Color.White else Color(0xFFFFCC00))
    // Tower Spire Eagle Perch
    drawCircle(
        color = beaconColor,
        radius = 18f,
        center = Offset(cx, cy),
        style = Stroke(width = 3.5f)
    )
    drawCircle(
        color = beaconColor.copy(alpha = 0.4f),
        radius = 10f,
        center = Offset(cx, cy)
    )
}

private fun DrawScope.drawCrowdPerson(p: CrowdPerson, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = p.pos.x + offsetX
    val cy = p.pos.y + offsetY

    // In Eagle Vision, crowds glow soft Blue
    val bodyColor = if (isEagle) {
        Color(0xFF29B6F6)
    } else {
        when (p.outfitColorType) {
            0 -> Color(0xFF2B5CB8) // Blue jacket
            1 -> Color(0xFFC8CBD5) // White shirt
            2 -> Color(0xFFB82A3A) // Red revolutionary
            else -> Color(0xFF907860) // Brown coat
        }
    }

    drawCircle(color = Color(0x44000000), radius = 9f, center = Offset(cx + 2f, cy + 3f))
    drawCircle(color = bodyColor, radius = 9f, center = Offset(cx, cy))
    // Head / Bonnet
    drawCircle(color = Color(0xFFE8C8A0), radius = 5f, center = Offset(cx, cy - 3f))

    if (p.isCheering) {
        // Flag or raised fist
        drawLine(Color(0xFFC22234), Offset(cx + 4f, cy), Offset(cx + 10f, cy - 12f), strokeWidth = 2.5f)
    }
}

private fun DrawScope.drawGuard(g: Guard, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    if (g.state == GuardState.DEAD) {
        // Draw fallen body
        val cx = g.pos.x + offsetX
        val cy = g.pos.y + offsetY
        drawCircle(color = Color(0x88661111), radius = 10f, center = Offset(cx, cy))
        return
    }

    val cx = g.pos.x + offsetX
    val cy = g.pos.y + offsetY

    // Vision Cone
    val coneColor = when (g.state) {
        GuardState.COMBAT -> Color(0x55E53935)
        GuardState.INVESTIGATING -> Color(0x44FB8C00)
        GuardState.SUSPICIOUS -> Color(0x33FDD835)
        else -> if (isEagle) Color(0x33E53935) else Color(0x18FFFFFF)
    }

    val coneRange = if (g.state == GuardState.COMBAT) 220f else 170f
    val fovHalf = PI.toFloat() / 3.4f
    val path = Path().apply {
        moveTo(cx, cy)
        val angleStart = g.facingAngle - fovHalf
        val angleEnd = g.facingAngle + fovHalf
        val steps = 8
        for (i in 0..steps) {
            val a = angleStart + (angleEnd - angleStart) * (i.toFloat() / steps)
            val px = cx + cos(a) * coneRange
            val py = cy + sin(a) * coneRange
            lineTo(px, py)
        }
        close()
    }
    drawPath(path, coneColor, style = Fill)

    // Body
    val guardColor = if (isEagle) {
        if (g.type == GuardType.MISSION_TARGET) Color(0xFFFFD700) else Color(0xFFFF3344)
    } else {
        when (g.type) {
            GuardType.MISSION_TARGET -> Color(0xFFE5A118)
            GuardType.ELITE_INQUISITOR -> Color(0xFF6B1D2F)
            GuardType.ROOFTOP_SNIPER -> Color(0xFF384358)
            else -> Color(0xFF34495E)
        }
    }

    drawCircle(color = Color(0x55000000), radius = 12f, center = Offset(cx + 3f, cy + 4f))
    drawCircle(color = guardColor, radius = 12f, center = Offset(cx, cy))

    // Facing direction sword/musket
    val barrelX = cx + cos(g.facingAngle) * 16f
    val barrelY = cy + sin(g.facingAngle) * 16f
    drawLine(Color.LightGray, Offset(cx, cy), Offset(barrelX, barrelY), strokeWidth = 3f)

    // Detection Meter Indicator Ring above guard head
    if (g.detectionMeter > 0f) {
        val meterColor = when {
            g.detectionMeter >= 1f -> Color(0xFFE53935)
            g.detectionMeter > 0.4f -> Color(0xFFFB8C00)
            else -> Color(0xFFFDD835)
        }
        drawArc(
            color = meterColor,
            startAngle = -90f,
            sweepAngle = g.detectionMeter * 360f,
            useCenter = false,
            topLeft = Offset(cx - 16f, cy - 30f),
            size = Size(32f, 32f),
            style = Stroke(width = 3.5f)
        )
    }

    // Target golden crown icon if mission target
    if (g.type == GuardType.MISSION_TARGET) {
        drawCircle(Color(0xFFFFD700), radius = 4f, center = Offset(cx, cy - 18f))
    }
}

private fun DrawScope.drawPlayer(p: Player, offsetX: Float, offsetY: Float, isEagle: Boolean) {
    val cx = p.pos.x + offsetX
    val cy = p.pos.y + offsetY

    // If leaping of faith
    if (p.posture == PlayerPosture.LEAP_OF_FAITH) {
        val s = 1f + p.leapOfFaithProgress * 0.8f
        drawCircle(Color(0xFF223A5E), radius = 18f * s, center = Offset(cx, cy))
        drawCircle(Color.White, radius = 8f * s, center = Offset(cx, cy))
        return
    }

    // If inside haystack
    if (p.isHiddenInHay) {
        drawCircle(Color(0xFF00E5FF), radius = 16f, center = Offset(cx, cy), style = Stroke(width = 2.5f))
        return
    }

    // Social Stealth Blended Ring
    if (p.isBlended) {
        drawCircle(
            color = Color(0x8829B6F6),
            radius = 26f,
            center = Offset(cx, cy),
            style = Stroke(width = 2.5f)
        )
    }

    // Shadow
    val shadowRadius = if (p.elevationZ > 0) 16f + p.elevationZ * 4f else 14f
    drawCircle(Color(0x55000000), radius = shadowRadius, center = Offset(cx + 4f, cy + 6f))

    // Arno's Master Assassin Body
    val coatColor = if (isEagle) Color(0xFFE0E6ED) else Color(0xFF1B2A4A)
    drawCircle(color = coatColor, radius = 14f, center = Offset(cx, cy))

    // Arno's White Hood & Red French Sash
    drawCircle(color = Color(0xFFE5E9F0), radius = 8f, center = Offset(cx, cy))
    drawCircle(color = Color(0xFFC22234), radius = 3.5f, center = Offset(cx, cy + 3f))

    // Facing Angle & Hidden Blade Gauntlet
    val bladeX = cx + cos(p.facingAngle) * 19f
    val bladeY = cy + sin(p.facingAngle) * 19f
    drawLine(Color(0xFFCCD6E0), Offset(cx, cy), Offset(bladeX, bladeY), strokeWidth = 3f)

    // Elevation badge if on rooftop or spire
    if (p.elevationZ > 0) {
        drawCircle(
            color = Color(0xFFFFCC00),
            radius = 4f,
            center = Offset(cx + 12f, cy - 12f)
        )
    }
}

private fun DrawScope.drawSmokeCloud(s: SmokeCloud, offsetX: Float, offsetY: Float) {
    val cx = s.pos.x + offsetX
    val cy = s.pos.y + offsetY
    val alpha = (s.duration / s.maxDuration).coerceIn(0f, 1f) * 0.65f

    drawCircle(
        color = Color(0xFFCFD8DC).copy(alpha = alpha),
        radius = s.radius,
        center = Offset(cx, cy)
    )
    drawCircle(
        color = Color(0xFF90A4AE).copy(alpha = alpha * 0.8f),
        radius = s.radius * 0.65f,
        center = Offset(cx, cy)
    )
}

private fun DrawScope.drawParticle(part: Particle, offsetX: Float, offsetY: Float) {
    val px = part.pos.x + offsetX
    val py = part.pos.y + offsetY
    val alpha = (part.life / part.maxLife).coerceIn(0f, 1f)

    drawCircle(
        color = Color(part.color).copy(alpha = alpha),
        radius = part.size,
        center = Offset(px, py)
    )
}

private fun DrawScope.drawAtmosphericPostProcessing(isEagle: Boolean) {
    if (isEagle) {
        // Eagle Vision blue tactical matrix overlay
        drawRect(
            Brush.radialGradient(
                colors = listOf(Color(0x110A1A2F), Color(0x66001026)),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = size.width * 0.7f
            )
        )
    } else {
        // Paris Revolutionary Dusk Vignette
        drawRect(
            Brush.radialGradient(
                colors = listOf(Color.Transparent, Color(0x55000000)),
                center = Offset(size.width / 2f, size.height / 2f),
                radius = size.width * 0.65f
            )
        )
    }
}
