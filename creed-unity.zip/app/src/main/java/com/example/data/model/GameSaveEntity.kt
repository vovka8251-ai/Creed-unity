package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "game_save")
data class GameSaveEntity(
    @PrimaryKey val id: Int = 1,
    val assassinRank: String = "Novice Assassin",
    val assassinLevel: Int = 1,
    val livres: Int = 450,
    val syncPoints: Int = 120,
    val smokeBombs: Int = 4,
    val phantomBlades: Int = 6,
    val lockpicks: Int = 5,
    val stealthKillsCount: Int = 0,
    val synchronizedViewpoints: Int = 0,
    val currentMissionId: String = "mission_notredame",
    val selectedGear: String = "Robes of Arno",
    val selectedWeapon: String = "French Rapier",
    val graphicsPreset: String = "UE5_CINEMATIC", // PERFORMANCE, FIDELITY, UE5_CINEMATIC
    val touchSensitivity: Float = 1.0f,
    val vibrationEnabled: Boolean = true
)

@Entity(tableName = "missions")
data class MissionEntity(
    @PrimaryKey val missionId: String,
    val title: String,
    val district: String,
    val targetName: String,
    val description: String,
    val rewardLivres: Int,
    val rewardSync: Int,
    val isCompleted: Boolean = false,
    val stealthBonusAchieved: Boolean = false,
    val difficultyStars: Int = 3
)
