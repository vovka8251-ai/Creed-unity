package com.example.data.repository

import com.example.data.db.GameDao
import com.example.data.model.FactionEntity
import com.example.data.model.FactionVendorItem
import com.example.data.model.GameSaveEntity
import com.example.data.model.MissionEntity
import kotlinx.coroutines.flow.Flow

class GameRepository(private val gameDao: GameDao) {
    val gameSaveFlow: Flow<GameSaveEntity?> = gameDao.getGameSaveFlow()
    val allMissionsFlow: Flow<List<MissionEntity>> = gameDao.getAllMissionsFlow()
    val allFactionsFlow: Flow<List<FactionEntity>> = gameDao.getAllFactionsFlow()
    val allVendorItemsFlow: Flow<List<FactionVendorItem>> = gameDao.getAllVendorItemsFlow()

    fun getVendorItemsByFaction(factionId: String): Flow<List<FactionVendorItem>> =
        gameDao.getVendorItemsByFaction(factionId)

    suspend fun ensureInitialized() {
        if (gameDao.getGameSave() == null) {
            gameDao.insertOrUpdateGameSave(GameSaveEntity())
        }
        if (gameDao.getMissionsCount() == 0) {
            gameDao.insertMissions(com.example.data.db.GameDatabase.getInitialMissions())
        }
        if (gameDao.getFactionsCount() == 0) {
            gameDao.insertFactions(com.example.data.db.GameDatabase.getInitialFactions())
        }
        if (gameDao.getVendorItemsCount() == 0) {
            gameDao.insertVendorItems(com.example.data.db.GameDatabase.getInitialVendorItems())
        }
    }

    suspend fun getGameSave(): GameSaveEntity? = gameDao.getGameSave()

    suspend fun saveGame(save: GameSaveEntity) {
        gameDao.insertOrUpdateGameSave(save)
    }

    suspend fun completeMission(missionId: String, stealthBonus: Boolean, livres: Int, sync: Int) {
        gameDao.markMissionComplete(missionId, stealthBonus)
        gameDao.addRewards(livres, sync)

        // Adjust faction reputations based on mission context
        when (missionId) {
            "mission_notredame" -> {
                gameDao.adjustFactionStanding("assassins", 15)
                gameDao.adjustFactionStanding("royalists", -20)
                gameDao.adjustFactionStanding("sanculottes", 10)
            }
            "mission_bastille" -> {
                gameDao.adjustFactionStanding("sanculottes", 25)
                gameDao.adjustFactionStanding("royalists", -30)
                gameDao.adjustFactionStanding("assassins", 10)
            }
            "mission_guillotine" -> {
                gameDao.adjustFactionStanding("sanculottes", 20)
                gameDao.adjustFactionStanding("smugglers", 15)
                gameDao.adjustFactionStanding("royalists", -25)
            }
            "mission_catacombs" -> {
                gameDao.adjustFactionStanding("assassins", 20)
                gameDao.adjustFactionStanding("smugglers", 25)
                gameDao.adjustFactionStanding("royalists", -15)
            }
        }
    }

    suspend fun adjustStanding(factionId: String, delta: Int) {
        gameDao.adjustFactionStanding(factionId, delta)
    }

    suspend fun recordStealthKill() {
        gameDao.incrementStealthKills()
        // Stealth kills honor the Assassin Creed tenets
        gameDao.adjustFactionStanding("assassins", 2)
    }

    suspend fun recordViewpointSync() {
        gameDao.incrementViewpoints()
        gameDao.addRewards(earnedLivres = 200, earnedSync = 100)
        gameDao.adjustFactionStanding("assassins", 8)
    }

    suspend fun updateConsumables(smokeBombs: Int, phantomBlades: Int) {
        gameDao.updateSmokeBombs(smokeBombs)
        gameDao.updatePhantomBlades(phantomBlades)
    }

    suspend fun setGraphicsPreset(preset: String) {
        gameDao.updateGraphicsPreset(preset)
    }

    suspend fun purchaseVendorItem(item: FactionVendorItem): Boolean {
        val save = gameDao.getGameSave() ?: return false
        if (save.livres >= item.costLivres && !item.isPurchased) {
            gameDao.deductLivres(item.costLivres)
            gameDao.markItemPurchased(item.itemId)

            // Apply item bonuses to save state
            when (item.itemId) {
                "item_phantom_quiver" -> gameDao.updatePhantomBlades(save.phantomBlades + 6)
                "item_barricade_smoke" -> gameDao.updateSmokeBombs(save.smokeBombs + 4)
                "item_master_robes" -> gameDao.insertOrUpdateGameSave(save.copy(selectedGear = item.name))
                "item_rev_pike", "item_dueling_rapier", "item_hidden_blades_adv" ->
                    gameDao.insertOrUpdateGameSave(save.copy(selectedWeapon = item.name))
            }
            return true
        }
        return false
    }
}
