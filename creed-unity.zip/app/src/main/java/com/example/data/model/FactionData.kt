package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class FactionType(val id: String, val displayName: String, val colorHex: Long) {
    ASSASSINS("assassins", "Assassin Brotherhood", 0xFFC22234),
    SANCULOTTES("sanculottes", "San-culottes Patriots", 0xFF2B5CB8),
    ROYALISTS("royalists", "Royalist Guard & Court", 0xFFC9A23A),
    SMUGGLERS("smugglers", "Cour des Miracles Smugglers", 0xFF2A8B58);

    companion object {
        fun fromId(id: String): FactionType = entries.find { it.id == id } ?: ASSASSINS
    }
}

enum class FactionTier(val displayName: String, val minStanding: Int, val isHostile: Boolean) {
    HATED("Hated (Kill on Sight)", -100, true),
    SUSPICIOUS("Suspicious (Fast Detection)", -30, false),
    NEUTRAL("Neutral", 0, false),
    FRIENDLY("Friendly (Vendor Access)", 30, false),
    ALLIED("Allied (Reinforcements)", 70, false);

    companion object {
        fun getTier(standing: Int): FactionTier = when {
            standing <= -31 -> HATED
            standing < 10 -> SUSPICIOUS
            standing < 40 -> NEUTRAL
            standing < 75 -> FRIENDLY
            else -> ALLIED
        }
    }
}

@Entity(tableName = "factions")
data class FactionEntity(
    @PrimaryKey val factionId: String,
    val name: String,
    val frenchTitle: String,
    val description: String,
    val standing: Int = 0, // -100 to 100
    val headquarters: String,
    val vendorName: String,
    val activeBonus: String
)

@Entity(tableName = "faction_vendor_items")
data class FactionVendorItem(
    @PrimaryKey val itemId: String,
    val factionId: String,
    val name: String,
    val itemType: String, // WEAPON, GEAR, GADGET, SKILL
    val description: String,
    val costLivres: Int,
    val requiredStanding: Int, // e.g. 30 for friendly, 70 for allied
    val isPurchased: Boolean = false,
    val statBoost: String
)
