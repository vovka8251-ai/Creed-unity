package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.model.FactionEntity
import com.example.data.model.FactionVendorItem
import com.example.data.model.GameSaveEntity
import com.example.data.model.MissionEntity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        GameSaveEntity::class,
        MissionEntity::class,
        FactionEntity::class,
        FactionVendorItem::class
    ],
    version = 2,
    exportSchema = false
)
abstract class GameDatabase : RoomDatabase() {
    abstract fun gameDao(): GameDao

    companion object {
        @Volatile
        private var INSTANCE: GameDatabase? = null

        fun getInstance(context: Context): GameDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    GameDatabase::class.java,
                    "creed_unity_paris.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }

        fun getInitialMissions(): List<MissionEntity> {
            return listOf(
                MissionEntity(
                    missionId = "mission_notredame",
                    title = "Shadow of Notre-Dame",
                    district = "Île de la Cité",
                    targetName = "Inquisitor Didier Valois",
                    description = "Infiltrate the cathedral plaza undetected. Eliminate the corrupt inquisitor overseeing executions (+Assassins, -Royalists).",
                    rewardLivres = 800,
                    rewardSync = 250,
                    difficultyStars = 2
                ),
                MissionEntity(
                    missionId = "mission_bastille",
                    title = "Bastille Garrison Infiltration",
                    district = "Faubourg Saint-Antoine",
                    targetName = "Captain Marc De Sica",
                    description = "Assist the San-culottes in taking the outer armory. Eliminate the royalist garrison captain (+San-culottes, -Royalists).",
                    rewardLivres = 1200,
                    rewardSync = 400,
                    difficultyStars = 3
                ),
                MissionEntity(
                    missionId = "mission_guillotine",
                    title = "Execution Square Ambush",
                    district = "Place de la Révolution",
                    targetName = "Judge Guillaume Lefebvre",
                    description = "Blend into the revolutionary crowd at the scaffold. Throw a smoke bomb to confuse guards and liberate prisoners (+San-culottes, +Smugglers).",
                    rewardLivres = 1500,
                    rewardSync = 500,
                    difficultyStars = 4
                ),
                MissionEntity(
                    missionId = "mission_catacombs",
                    title = "Paris Catacombs Sabotage",
                    district = "Les Halles Catacombs",
                    targetName = "Templar Master Le Peletier",
                    description = "Descend into the ossuary catacombs beneath Paris. Eliminate the elite royalist guard and secure the smuggler weapon stash (+Assassins, +Smugglers).",
                    rewardLivres = 2000,
                    rewardSync = 750,
                    difficultyStars = 5
                )
            )
        }

        fun getInitialFactions(): List<FactionEntity> {
            return listOf(
                FactionEntity(
                    factionId = "assassins",
                    name = "Assassin Brotherhood",
                    frenchTitle = "La Confrérie des Assassins",
                    description = "The clandestine Parisian brotherhood guiding the revolution towards liberty and defending citizens against Templar plots.",
                    standing = 40,
                    headquarters = "Sainte-Chapelle Crypt",
                    vendorName = "Master Quartermaster Bellec",
                    activeBonus = "+25% Eagle Vision range & silent rooftop parkour"
                ),
                FactionEntity(
                    factionId = "sanculottes",
                    name = "San-culottes Patriots",
                    frenchTitle = "Les Sans-Culottes de Paris",
                    description = "Armed Parisian commoners and revolutionaries storming fortresses and defending street barricades against royalist forces.",
                    standing = 25,
                    headquarters = "Faubourg Saint-Antoine",
                    vendorName = "Citizen Smith Théroigne",
                    activeBonus = "Faster crowd blending & armed citizen riot assistance in street brawls"
                ),
                FactionEntity(
                    factionId = "royalists",
                    name = "Royalist Guard & Nobles",
                    frenchTitle = "Gardes Françaises et Noblesse",
                    description = "The old regime's Swiss guards and aristocratic gendarmerie protecting noble salons and palatial districts.",
                    standing = -15,
                    headquarters = "Palais des Tuileries & Saint-Honoré",
                    vendorName = "Master Bladesmith De Valois",
                    activeBonus = "Safe passage through noble estates; if Hated, elite hunters attack on sight"
                ),
                FactionEntity(
                    factionId = "smugglers",
                    name = "Cour des Miracles Smugglers",
                    frenchTitle = "La Cour des Miracles",
                    description = "Underworld syndicate of Parisian cutpurses, catacombs scavengers, and black market munitions dealers.",
                    standing = 15,
                    headquarters = "Les Halles Underground Ossuary",
                    vendorName = "The King of Beggars' Fence",
                    activeBonus = "Smoke bombs and phantom ammo restock discount & skeleton lockpicks"
                )
            )
        }

        fun getInitialVendorItems(): List<FactionVendorItem> {
            return listOf(
                // Assassins
                FactionVendorItem(
                    itemId = "item_master_robes",
                    factionId = "assassins",
                    name = "Master Assassin Robes",
                    itemType = "GEAR",
                    description = "Tailored Parisian velvet robes with hood. Greatly dampens footsteps and halves guard detection speed.",
                    costLivres = 1200,
                    requiredStanding = 35,
                    statBoost = "-50% Guard Detection Rate"
                ),
                FactionVendorItem(
                    itemId = "item_phantom_quiver",
                    factionId = "assassins",
                    name = "Expanded Phantom Quiver",
                    itemType = "GADGET",
                    description = "Specialized wrist harness allowing Arno to carry +6 additional Phantom Blades.",
                    costLivres = 750,
                    requiredStanding = 45,
                    statBoost = "+6 Phantom Blade Ammo"
                ),
                FactionVendorItem(
                    itemId = "item_hidden_blades_adv",
                    factionId = "assassins",
                    name = "Dual Guillotine Hidden Blades",
                    itemType = "WEAPON",
                    description = "Masterwork spring-steel hidden blades capable of silent double takedowns.",
                    costLivres = 1800,
                    requiredStanding = 70,
                    statBoost = "Double Stealth Assassinations"
                ),

                // San-culottes
                FactionVendorItem(
                    itemId = "item_rev_pike",
                    factionId = "sanculottes",
                    name = "Revolutionary Iron Pike",
                    itemType = "WEAPON",
                    description = "Sturdy street combat polearm used by Parisian mob leaders to break heavy cavalry.",
                    costLivres = 600,
                    requiredStanding = 20,
                    statBoost = "+35% Heavy Melee Impact"
                ),
                FactionVendorItem(
                    itemId = "item_barricade_smoke",
                    factionId = "sanculottes",
                    name = "Dense Barricade Smoke Canisters",
                    itemType = "GADGET",
                    description = "High-potency sulfur smoke bombs that linger for 12 seconds in crowded plazas.",
                    costLivres = 500,
                    requiredStanding = 30,
                    statBoost = "+4s Smoke Cloud Duration"
                ),
                FactionVendorItem(
                    itemId = "item_patriot_cockade",
                    factionId = "sanculottes",
                    name = "Master Patriot's Tricolor Cockade",
                    itemType = "GEAR",
                    description = "Recognized insignia of the revolution. Allows blending into crowds with only 2 citizens.",
                    costLivres = 950,
                    requiredStanding = 60,
                    statBoost = "Instant Crowd Social Stealth"
                ),

                // Royalist
                FactionVendorItem(
                    itemId = "item_dueling_rapier",
                    factionId = "royalists",
                    name = "Ornate French Dueling Rapier",
                    itemType = "WEAPON",
                    description = "Elegantly balanced Toledo steel blade favored by Parisian aristocrats and court masters.",
                    costLivres = 1100,
                    requiredStanding = 10,
                    statBoost = "+40% Parry & Counter Damage"
                ),
                FactionVendorItem(
                    itemId = "item_officer_cuirass",
                    factionId = "royalists",
                    name = "Gendarme Officer's Cuirass",
                    itemType = "GEAR",
                    description = "Tempered steel breastplate that withstands musket fire and sword slashes.",
                    costLivres = 1400,
                    requiredStanding = 40,
                    statBoost = "+50 Max Health Capacity"
                ),

                // Smugglers
                FactionVendorItem(
                    itemId = "item_skeleton_lockpicks",
                    factionId = "smugglers",
                    name = "Master Skeleton Lockpicks",
                    itemType = "GADGET",
                    description = "Finely tuned thief lockpicks that open Parisian locked chests effortlessly.",
                    costLivres = 400,
                    requiredStanding = 15,
                    statBoost = "Auto-pick Paris Treasure Chests"
                ),
                FactionVendorItem(
                    itemId = "item_poison_phantom",
                    factionId = "smugglers",
                    name = "Poisoned Phantom Dart Vials",
                    itemType = "GADGET",
                    description = "Deadly Belladonna-coated darts that cause targets to hallucinate before falling silently.",
                    costLivres = 850,
                    requiredStanding = 35,
                    statBoost = "Silent Long-Range Poison Dart"
                )
            )
        }
    }
}
