package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.FactionEntity
import com.example.data.model.FactionVendorItem
import com.example.data.model.GameSaveEntity
import com.example.data.model.MissionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface GameDao {
    @Query("SELECT * FROM game_save WHERE id = 1")
    fun getGameSaveFlow(): Flow<GameSaveEntity?>

    @Query("SELECT * FROM game_save WHERE id = 1")
    suspend fun getGameSave(): GameSaveEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateGameSave(save: GameSaveEntity)

    @Query("SELECT * FROM missions")
    fun getAllMissionsFlow(): Flow<List<MissionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMissions(missions: List<MissionEntity>)

    @Update
    suspend fun updateMission(mission: MissionEntity)

    @Query("UPDATE missions SET isCompleted = 1, stealthBonusAchieved = :stealthBonus WHERE missionId = :id")
    suspend fun markMissionComplete(id: String, stealthBonus: Boolean)

    @Query("UPDATE game_save SET livres = livres + :earnedLivres, syncPoints = syncPoints + :earnedSync WHERE id = 1")
    suspend fun addRewards(earnedLivres: Int, earnedSync: Int)

    @Query("UPDATE game_save SET stealthKillsCount = stealthKillsCount + 1 WHERE id = 1")
    suspend fun incrementStealthKills()

    @Query("UPDATE game_save SET synchronizedViewpoints = synchronizedViewpoints + 1 WHERE id = 1")
    suspend fun incrementViewpoints()

    @Query("UPDATE game_save SET smokeBombs = :count WHERE id = 1")
    suspend fun updateSmokeBombs(count: Int)

    @Query("UPDATE game_save SET phantomBlades = :count WHERE id = 1")
    suspend fun updatePhantomBlades(count: Int)

    @Query("UPDATE game_save SET graphicsPreset = :preset WHERE id = 1")
    suspend fun updateGraphicsPreset(preset: String)

    // FACTIONS
    @Query("SELECT * FROM factions")
    fun getAllFactionsFlow(): Flow<List<FactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertFactions(factions: List<FactionEntity>)

    @Query("UPDATE factions SET standing = MIN(100, MAX(-100, standing + :delta)) WHERE factionId = :factionId")
    suspend fun adjustFactionStanding(factionId: String, delta: Int)

    // VENDOR ITEMS
    @Query("SELECT * FROM faction_vendor_items")
    fun getAllVendorItemsFlow(): Flow<List<FactionVendorItem>>

    @Query("SELECT * FROM faction_vendor_items WHERE factionId = :factionId")
    fun getVendorItemsByFaction(factionId: String): Flow<List<FactionVendorItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVendorItems(items: List<FactionVendorItem>)

    @Query("UPDATE faction_vendor_items SET isPurchased = 1 WHERE itemId = :itemId")
    suspend fun markItemPurchased(itemId: String)

    @Query("SELECT COUNT(*) FROM missions")
    suspend fun getMissionsCount(): Int

    @Query("SELECT COUNT(*) FROM factions")
    suspend fun getFactionsCount(): Int

    @Query("SELECT COUNT(*) FROM faction_vendor_items")
    suspend fun getVendorItemsCount(): Int

    @Query("UPDATE game_save SET livres = livres - :cost WHERE id = 1 AND livres >= :cost")
    suspend fun deductLivres(cost: Int)
}
