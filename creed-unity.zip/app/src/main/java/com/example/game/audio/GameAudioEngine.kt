package com.example.game.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Procedural low-latency Audio Engine for Assassin's Creed sound design.
 * Generates metallic hidden blades, smoke explosions, eagle cries, and Eagle Vision pulses.
 */
class GameAudioEngine {
    private val scope = CoroutineScope(Dispatchers.Default)
    private val sampleRate = 44100

    private fun playPcm(generator: () -> ShortArray) {
        scope.launch {
            try {
                val samples = generator()
                val minBufferSize = AudioTrack.getMinBufferSize(
                    sampleRate,
                    AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT
                )
                val bufferSize = maxOf(minBufferSize, samples.size * 2)

                val audioTrack = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_GAME)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()

                audioTrack.write(samples, 0, samples.size)
                audioTrack.play()
                // Auto release after sound finishes
                scope.launch {
                    val durationMs = (samples.size.toFloat() / sampleRate * 1000).toLong() + 100
                    kotlinx.coroutines.delay(durationMs)
                    try {
                        audioTrack.stop()
                        audioTrack.release()
                    } catch (_: Exception) {}
                }
            } catch (_: Exception) {
                // Ignore audio init issues if system device is unavailable
            }
        }
    }

    /**
     * Iconic hidden blade extension "SHINK-CLACK" sound.
     */
    fun playHiddenBlade() {
        playPcm {
            val length = (sampleRate * 0.28).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                // Metallic scrape: rising frequency + harmonic overtones
                val freq = 1200f + t * 4500f
                val env = exp((-12.0 * t).toDouble()).toFloat()
                val wave = sin(2.0 * PI * freq * t) * 0.6f +
                        sin(2.0 * PI * (freq * 2.3f) * t) * 0.3f +
                        (Math.random().toFloat() * 2f - 1f) * 0.15f
                val sampleVal = (wave * env * 30000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Assassination lethal strike impact with deep bass punch.
     */
    fun playAssassinationImpact() {
        playPcm {
            val length = (sampleRate * 0.35).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = exp((-10.0 * t).toDouble()).toFloat()
                val bass = sin(2.0 * PI * (90.0 - t * 40.0) * t).toFloat() * 0.7f
                val sliceNoise = (Math.random().toFloat() * 2f - 1f) * exp((-25.0 * t).toDouble()).toFloat() * 0.5f
                val sampleVal = ((bass + sliceNoise) * env * 32000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Eagle Vision pulse sound: Animus cyber-echo + mystic resonance.
     */
    fun playEagleVisionPulse() {
        playPcm {
            val length = (sampleRate * 0.6).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = sin(PI * (t / 0.6)).toFloat()
                val tone1 = sin(2.0 * PI * 432.0 * t).toFloat() * 0.5f
                val tone2 = sin(2.0 * PI * 864.0 * t).toFloat() * 0.3f
                val chime = sin(2.0 * PI * 1728.0 * t).toFloat() * 0.2f
                val sampleVal = ((tone1 + tone2 + chime) * env * 26000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Smoke bomb explosion: loud crack and white noise hiss.
     */
    fun playSmokeBomb() {
        playPcm {
            val length = (sampleRate * 0.5).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = exp((-6.0 * t).toDouble()).toFloat()
                val noise = (Math.random().toFloat() * 2f - 1f) * 0.8f
                val lowPop = sin(2.0 * PI * 120.0 * (1f - t) * t).toFloat() * exp((-20.0 * t).toDouble()).toFloat()
                val sampleVal = ((noise + lowPop) * env * 28000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Phantom blade release: High-tension mechanical crossbow snap.
     */
    fun playPhantomBlade() {
        playPcm {
            val length = (sampleRate * 0.22).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = exp((-15.0 * t).toDouble()).toFloat()
                val snap = sin(2.0 * PI * (2200.0 - t * 1800.0) * t).toFloat() * 0.7f
                val noise = (Math.random().toFloat() * 2f - 1f) * 0.3f
                val sampleVal = ((snap + noise) * env * 29000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Leap of Faith / Viewpoint Eagle Screech.
     */
    fun playEagleCry() {
        playPcm {
            val length = (sampleRate * 0.8).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = sin(PI * (t / 0.8)).toFloat()
                // Frequency sweep mimicking eagle cry: 1800 -> 3200 -> 2400
                val freq = 1800.0 + sin(t * 3.5) * 1400.0
                val wave = sin(2.0 * PI * freq * t).toFloat() * 0.6f +
                        sin(2.0 * PI * (freq * 1.5) * t).toFloat() * 0.3f
                val sampleVal = (wave * env * 27000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Guard detection suspicion alert sting.
     */
    fun playGuardAlert() {
        playPcm {
            val length = (sampleRate * 0.4).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = exp((-7.0 * t).toDouble()).toFloat()
                // Dissonant interval (minor 2nd tritone chord)
                val f1 = sin(2.0 * PI * 587.33 * t).toFloat() * 0.45f
                val f2 = sin(2.0 * PI * 622.25 * t).toFloat() * 0.45f
                val sampleVal = ((f1 + f2) * env * 27000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }

    /**
     * Arno parkour leap / rooftop footstep tile sound.
     */
    fun playParkourStep() {
        playPcm {
            val length = (sampleRate * 0.1).toInt()
            val data = ShortArray(length)
            for (i in 0 until length) {
                val t = i.toFloat() / sampleRate
                val env = exp((-28.0 * t).toDouble()).toFloat()
                val thud = sin(2.0 * PI * 180.0 * t).toFloat() * 0.6f
                val gravel = (Math.random().toFloat() * 2f - 1f) * 0.35f
                val sampleVal = ((thud + gravel) * env * 22000).toInt().coerceIn(-32767, 32767)
                data[i] = sampleVal.toShort()
            }
            data
        }
    }
}
