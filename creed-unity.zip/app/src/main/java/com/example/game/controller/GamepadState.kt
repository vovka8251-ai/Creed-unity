package com.example.game.controller

import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent

/**
 * Encapsulates gamepad hardware detection and mapping for external controllers
 * (Xbox, PlayStation, Razer Kishi, Android gamepads).
 */
data class GamepadInputState(
    val isControllerConnected: Boolean = false,
    val controllerName: String = "",
    val stickX: Float = 0f,
    val stickY: Float = 0f,
    val rightStickX: Float = 0f,
    val rightStickY: Float = 0f,
    val btnA: Boolean = false,      // Parkour / Jump / Free Run
    val btnB: Boolean = false,      // Crouch / Stealth / Drop Down
    val btnX: Boolean = false,      // Assassinate / Attack
    val btnY: Boolean = false,      // Eagle Vision
    val btnL1: Boolean = false,     // Whistle
    val btnR1: Boolean = false,     // Gadget (Smoke Bomb / Phantom Blade)
    val btnL2: Float = 0f,          // Aim / Target Lock
    val btnR2: Float = 0f,          // High Profile Sprint
    val btnStart: Boolean = false,  // Map / Pause
    val btnSelect: Boolean = false  // Objectives
)

class GamepadHandler {

    companion object {
        fun isGamepadConnected(): Pair<Boolean, String> {
            return try {
                val deviceIds = InputDevice.getDeviceIds()
                for (id in deviceIds) {
                    val dev = InputDevice.getDevice(id) ?: continue
                    val sources = dev.sources
                    val isGamepad = (sources and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                            (sources and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK
                    if (isGamepad && !dev.isVirtual) {
                        return true to (dev.name ?: "Generic Gamepad")
                    }
                }
                false to ""
            } catch (_: Exception) {
                false to ""
            }
        }

        fun applyDeadzone(value: Float, deadzone: Float = 0.18f): Float {
            return if (kotlin.math.abs(value) < deadzone) 0f else {
                val sign = if (value > 0) 1f else -1f
                sign * ((kotlin.math.abs(value) - deadzone) / (1f - deadzone))
            }
        }
    }
}
