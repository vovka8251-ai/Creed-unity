package com.example.game.engine

enum class PlayerPosture {
    STAND,
    CROUCH_STEALTH,
    SPRINT_PARKOUR,
    CLIMBING,
    ROOFTOP_PERCH,
    IN_HAYSTACK,
    BLENDED_IN_CROWD,
    LEAP_OF_FAITH,
    ATTACKING
}

enum class GadgetType {
    SMOKE_BOMB,
    PHANTOM_BLADE,
    WHISTLE
}

enum class GuardType {
    REVOLUTIONARY_MILITIA,
    ROYALIST_SOLDIER,
    ELITE_INQUISITOR,
    ROOFTOP_SNIPER,
    MISSION_TARGET
}

enum class GuardState {
    UNAWARE,
    SUSPICIOUS,
    INVESTIGATING,
    COMBAT,
    STUNNED,
    DEAD
}

data class Vector2D(val x: Float, val y: Float) {
    operator fun plus(other: Vector2D) = Vector2D(x + other.x, y + other.y)
    operator fun minus(other: Vector2D) = Vector2D(x - other.x, y - other.y)
    operator fun times(scale: Float) = Vector2D(x * scale, y * scale)
    fun length(): Float = kotlin.math.sqrt(x * x + y * y)
    fun distanceTo(other: Vector2D): Float = (this - other).length()
    fun normalized(): Vector2D {
        val l = length()
        return if (l > 0.0001f) Vector2D(x / l, y / l) else Vector2D(0f, 0f)
    }
}

data class Player(
    var pos: Vector2D = Vector2D(400f, 600f),
    var elevationZ: Int = 0, // 0 = street, 1 = mid/balcony, 2 = rooftop, 3 = high spire
    var facingAngle: Float = 0f,
    var posture: PlayerPosture = PlayerPosture.STAND,
    var health: Float = 100f,
    var maxHealth: Float = 100f,
    var inStealth: Boolean = false,
    var isBlended: Boolean = false,
    var isHiddenInHay: Boolean = false,
    var selectedGadget: GadgetType = GadgetType.SMOKE_BOMB,
    var smokeBombs: Int = 4,
    var phantomBlades: Int = 6,
    var livresEarnedThisRun: Int = 0,
    var currentStreak: Int = 0,
    var isEagleVisionActive: Boolean = false,
    var eagleVisionTimer: Float = 0f,
    var leapOfFaithProgress: Float = 0f,
    var attackAnimTimer: Float = 0f
)

data class Guard(
    val id: Int,
    var pos: Vector2D,
    val type: GuardType,
    var elevationZ: Int = 0,
    var facingAngle: Float = 0f,
    var state: GuardState = GuardState.UNAWARE,
    var detectionMeter: Float = 0f, // 0.0 to 1.0f
    var patrolPath: List<Vector2D> = emptyList(),
    var currentPatrolIndex: Int = 0,
    var health: Float = 100f,
    var investigateTarget: Vector2D? = null,
    var stunnedTimer: Float = 0f,
    var attackCooldown: Float = 0f,
    val name: String = "Sentry"
)

data class CrowdPerson(
    val id: Int,
    var pos: Vector2D,
    var facingAngle: Float,
    val outfitColorType: Int, // 0 = Blue coat, 1 = White apron, 2 = Red cockade, 3 = Tricolor flag bearer
    var isCheering: Boolean = false
)

data class Building(
    val id: Int,
    val x: Float,
    val y: Float,
    val width: Float,
    val height: Float,
    val elevationZ: Int = 2,
    val name: String = "Building",
    val isNotreDame: Boolean = false,
    val colorHex: Long = 0xFF353C4D
)

data class Viewpoint(
    val id: Int,
    val name: String,
    val pos: Vector2D,
    val elevationZ: Int = 3,
    var isSynchronized: Boolean = false,
    val district: String
)

data class Haystack(
    val id: Int,
    val pos: Vector2D,
    val radius: Float = 36f
)

data class LootChest(
    val id: Int,
    val pos: Vector2D,
    val elevationZ: Int = 0,
    val livres: Int = 150,
    var isOpened: Boolean = false
)

data class SmokeCloud(
    val pos: Vector2D,
    var duration: Float = 8f,
    val maxDuration: Float = 8f,
    val radius: Float = 95f
)

data class Particle(
    var pos: Vector2D,
    var vel: Vector2D,
    var life: Float,
    val maxLife: Float,
    val color: Long,
    val size: Float
)

data class PrisonerCage(
    val id: Int,
    val pos: Vector2D,
    val name: String,
    var isLiberated: Boolean = false
)

