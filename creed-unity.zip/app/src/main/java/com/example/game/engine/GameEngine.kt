package com.example.game.engine

import android.os.Vibrator
import com.example.game.audio.GameAudioEngine
import com.example.game.controller.GamepadInputState
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

class GameEngine(
    private val audioEngine: GameAudioEngine,
    private val vibrator: Vibrator?,
    var onMissionComplete: (missionId: String, stealthBonus: Boolean, livres: Int, sync: Int) -> Unit = { _, _, _, _ -> },
    var onViewpointSynced: (viewpointName: String) -> Unit = {},
    var onStealthKillAchieved: () -> Unit = {}
) {
    val player = Player()
    val guards = mutableListOf<Guard>()
    val crowds = mutableListOf<CrowdPerson>()
    val buildings = mutableListOf<Building>()
    val viewpoints = mutableListOf<Viewpoint>()
    val haystacks = mutableListOf<Haystack>()
    val lootChests = mutableListOf<LootChest>()
    val smokeClouds = mutableListOf<SmokeCloud>()
    val particles = mutableListOf<Particle>()
    val prisonerCages = mutableListOf<PrisonerCage>()

    var onFactionStandingChanged: (factionId: String, delta: Int, reason: String) -> Unit = { _, _, _ -> }
    var factionStandings = mutableMapOf(
        "assassins" to 40,
        "sanculottes" to 25,
        "royalists" to -15,
        "smugglers" to 15
    )

    var activeMissionId: String = "mission_notredame"
    var activeMissionTitle: String = "Shadow of Notre-Dame"
    var activeTargetName: String = "Inquisitor Didier Valois"
    var activeDistrict: String = "Île de la Cité"
    var isMissionCompleted: Boolean = false
    var detectedCount: Int = 0
    var lastKnownPosition: Vector2D? = null

    // Camera offset
    var cameraX: Float = 400f
    var cameraY: Float = 600f
    var cameraZoom: Float = 1.0f
    var syncCameraAngle: Float = 0f
    var isSynchronizingViewpoint: Boolean = false

    // Contextual prompts for HUD
    var canAssassinateTarget: Guard? = null
    var isAirAssassinationPossible: Boolean = false
    var canSynchronizeViewpoint: Viewpoint? = null
    var canLootChest: LootChest? = null
    var canHideInHaystack: Haystack? = null
    var canLiberateCage: PrisonerCage? = null

    // Notifications
    var bannerMessage: String? = "Welcome to Paris, 1789. Infiltrate Notre-Dame undetected."
    var bannerTimer: Float = 5f

    init {
        initParisOpenWorld()
    }

    private fun initParisOpenWorld() {
        // Paris Map Size ~ 2200 x 2200
        buildings.clear()
        // Notre-Dame Cathedral Complex
        buildings.add(Building(1, 400f, 300f, 380f, 260f, elevationZ = 3, name = "Notre-Dame Cathedral", isNotreDame = true, colorHex = 0xFF2B3347))
        buildings.add(Building(2, 400f, 150f, 160f, 140f, elevationZ = 3, name = "North Tower Spire", isNotreDame = true, colorHex = 0xFF22293A))
        buildings.add(Building(3, 620f, 150f, 160f, 140f, elevationZ = 3, name = "South Tower Spire", isNotreDame = true, colorHex = 0xFF22293A))

        // Residential Revolutionary Paris Blocks
        buildings.add(Building(4, 150f, 750f, 220f, 180f, elevationZ = 2, name = "Rue Saint-Denis Tenements", colorHex = 0xFF3E3B46))
        buildings.add(Building(5, 430f, 750f, 240f, 180f, elevationZ = 2, name = "Artisan Guild Hall", colorHex = 0xFF453F4C))
        buildings.add(Building(6, 730f, 750f, 260f, 180f, elevationZ = 2, name = "Revolutionary Print Shop", colorHex = 0xFF3D3848))

        // Place de la Révolution & Guillotine District
        buildings.add(Building(7, 1200f, 350f, 300f, 200f, elevationZ = 2, name = "Tribunal Courthouse", colorHex = 0xFF343B4E))
        buildings.add(Building(8, 1200f, 700f, 280f, 190f, elevationZ = 2, name = "National Guard Barracks", colorHex = 0xFF3A3546))
        buildings.add(Building(9, 1550f, 500f, 260f, 240f, elevationZ = 2, name = "Saint-Honoré Mansions", colorHex = 0xFF423B4A))

        // Conciergerie & Catacombs entrances
        buildings.add(Building(10, 850f, 1200f, 320f, 250f, elevationZ = 2, name = "Conciergerie Fortress", colorHex = 0xFF2F364A))
        buildings.add(Building(11, 400f, 1200f, 280f, 220f, elevationZ = 2, name = "Hôtel de Ville", colorHex = 0xFF3A3B46))

        // Haystacks for Leaps of Faith
        haystacks.clear()
        haystacks.add(Haystack(1, Vector2D(590f, 320f))) // Beside Notre-Dame
        haystacks.add(Haystack(2, Vector2D(390f, 740f))) // Rue Saint-Denis alley
        haystacks.add(Haystack(3, Vector2D(1350f, 580f))) // Near Guillotine square
        haystacks.add(Haystack(4, Vector2D(990f, 1190f))) // Outside Conciergerie

        // Viewpoints
        viewpoints.clear()
        viewpoints.add(Viewpoint(1, "Notre-Dame Spire", Vector2D(480f, 170f), elevationZ = 3, district = "Île de la Cité"))
        viewpoints.add(Viewpoint(2, "Saint-Honoré Clocktower", Vector2D(1680f, 520f), elevationZ = 3, district = "Saint-Honoré"))
        viewpoints.add(Viewpoint(3, "Conciergerie Bastion", Vector2D(1010f, 1220f), elevationZ = 3, district = "Palais de Justice"))

        // Loot Chests
        lootChests.clear()
        lootChests.add(LootChest(1, Vector2D(540f, 240f), elevationZ = 2, livres = 300))
        lootChests.add(LootChest(2, Vector2D(260f, 840f), elevationZ = 0, livres = 180))
        lootChests.add(LootChest(3, Vector2D(1440f, 450f), elevationZ = 2, livres = 450))
        lootChests.add(LootChest(4, Vector2D(950f, 1320f), elevationZ = 0, livres = 320))

        // Revolutionary Prisoner Cages (Public Acts)
        prisonerCages.clear()
        prisonerCages.add(PrisonerCage(1, Vector2D(1330f, 620f), "Place de la Révolution Scaffold Cell"))
        prisonerCages.add(PrisonerCage(2, Vector2D(930f, 1260f), "Conciergerie Royalist Stockade"))

        // Crowds (Parisian citizens protesting, chatting, blending spots)
        crowds.clear()
        // Notre Dame plaza crowd
        val baseNotreDame = Vector2D(590f, 600f)
        for (i in 0 until 35) {
            val angle = (i * 37) % 360 * (PI.toFloat() / 180f)
            val dist = 25f + (i * 7f) % 90f
            crowds.add(CrowdPerson(i, baseNotreDame + Vector2D(cos(angle) * dist, sin(angle) * dist), angle, i % 4, isCheering = i % 3 == 0))
        }
        // Guillotine square angry mob
        val baseGuillotine = Vector2D(1380f, 520f)
        for (i in 35 until 85) {
            val angle = (i * 29) % 360 * (PI.toFloat() / 180f)
            val dist = 20f + (i * 6f) % 110f
            crowds.add(CrowdPerson(i, baseGuillotine + Vector2D(cos(angle) * dist, sin(angle) * dist), angle, i % 4, isCheering = true))
        }

        // Guards & Mission Target
        spawnGuardsForMission(activeMissionId)
    }

    fun loadMission(missionId: String, title: String, target: String, district: String) {
        activeMissionId = missionId
        activeMissionTitle = title
        activeTargetName = target
        activeDistrict = district
        isMissionCompleted = false
        detectedCount = 0
        bannerMessage = "CONTRACT ACCEPTED: $title - Eliminate $target"
        bannerTimer = 6f
        spawnGuardsForMission(missionId)
    }

    private fun spawnGuardsForMission(missionId: String) {
        guards.clear()
        when (missionId) {
            "mission_notredame" -> {
                // Target: Inquisitor Didier Valois in Notre-Dame plaza
                guards.add(
                    Guard(
                        id = 1,
                        pos = Vector2D(500f, 480f),
                        type = GuardType.MISSION_TARGET,
                        elevationZ = 0,
                        name = "Inquisitor Didier Valois",
                        patrolPath = listOf(Vector2D(500f, 480f), Vector2D(580f, 500f), Vector2D(540f, 440f))
                    )
                )
                // Personal elite guards
                guards.add(Guard(2, Vector2D(460f, 460f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Inquisition Bodyguard"))
                guards.add(Guard(3, Vector2D(540f, 520f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Inquisition Bodyguard"))
                // Plaza sentries
                guards.add(Guard(4, Vector2D(350f, 620f), GuardType.ROYALIST_SOLDIER, elevationZ = 0, patrolPath = listOf(Vector2D(350f, 620f), Vector2D(420f, 680f)), name = "Plaza Sentry"))
                guards.add(Guard(5, Vector2D(700f, 620f), GuardType.ROYALIST_SOLDIER, elevationZ = 0, patrolPath = listOf(Vector2D(700f, 620f), Vector2D(640f, 690f)), name = "Plaza Sentry"))
                // Cathedral rooftop snipers
                guards.add(Guard(6, Vector2D(480f, 260f), GuardType.ROOFTOP_SNIPER, elevationZ = 2, name = "Rooftop Sniper"))
                guards.add(Guard(7, Vector2D(650f, 260f), GuardType.ROOFTOP_SNIPER, elevationZ = 2, name = "Rooftop Sniper"))
            }
            "mission_bastille" -> {
                guards.add(Guard(1, Vector2D(1000f, 1300f), GuardType.MISSION_TARGET, elevationZ = 0, name = "Captain Marc De Sica"))
                guards.add(Guard(2, Vector2D(970f, 1260f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Fortress Lieutenant"))
                guards.add(Guard(3, Vector2D(1050f, 1260f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Fortress Lieutenant"))
                guards.add(Guard(4, Vector2D(900f, 1200f), GuardType.ROOFTOP_SNIPER, elevationZ = 2, name = "Bastion Marksman"))
                guards.add(Guard(5, Vector2D(1120f, 1200f), GuardType.ROOFTOP_SNIPER, elevationZ = 2, name = "Bastion Marksman"))
            }
            "mission_guillotine" -> {
                guards.add(Guard(1, Vector2D(1380f, 520f), GuardType.MISSION_TARGET, elevationZ = 0, name = "Judge Guillaume Lefebvre"))
                guards.add(Guard(2, Vector2D(1350f, 490f), GuardType.REVOLUTIONARY_MILITIA, elevationZ = 0, name = "Tribunal Enforcer"))
                guards.add(Guard(3, Vector2D(1410f, 490f), GuardType.REVOLUTIONARY_MILITIA, elevationZ = 0, name = "Tribunal Enforcer"))
                guards.add(Guard(4, Vector2D(1380f, 560f), GuardType.REVOLUTIONARY_MILITIA, elevationZ = 0, name = "Tribunal Enforcer"))
                guards.add(Guard(5, Vector2D(1520f, 450f), GuardType.ROOFTOP_SNIPER, elevationZ = 2, name = "Courthouse Watcher"))
            }
            else -> {
                guards.add(Guard(1, Vector2D(800f, 800f), GuardType.MISSION_TARGET, elevationZ = 0, name = "Templar Master Le Peletier"))
                guards.add(Guard(2, Vector2D(770f, 780f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Catacomb Zealot"))
                guards.add(Guard(3, Vector2D(830f, 820f), GuardType.ELITE_INQUISITOR, elevationZ = 0, name = "Catacomb Zealot"))
            }
        }
    }

    /**
     * Main Game Loop Tick (60 FPS)
     */
    fun update(
        dt: Float,
        moveX: Float,
        moveY: Float,
        isSprintPressed: Boolean,
        isCrouchPressed: Boolean,
        gamepadState: GamepadInputState?
    ) {
        if (bannerTimer > 0f) {
            bannerTimer -= dt
            if (bannerTimer <= 0f) bannerMessage = null
        }

        // External Controller Button Mapping Check
        val effectiveMoveX: Float
        val effectiveMoveY: Float
        val effectiveSprint: Boolean
        val effectiveCrouch: Boolean

        if (gamepadState != null && gamepadState.isControllerConnected) {
            effectiveMoveX = if (kotlin.math.abs(gamepadState.stickX) > 0.05f) gamepadState.stickX else moveX
            effectiveMoveY = if (kotlin.math.abs(gamepadState.stickY) > 0.05f) gamepadState.stickY else moveY
            effectiveSprint = isSprintPressed || gamepadState.btnA || gamepadState.btnR2 > 0.3f
            effectiveCrouch = isCrouchPressed || gamepadState.btnB
            if (gamepadState.btnX) triggerAssassination()
            if (gamepadState.btnY && player.eagleVisionTimer <= 0f) toggleEagleVision()
            if (gamepadState.btnR1) useGadget()
            if (gamepadState.btnL1) whistle()
        } else {
            effectiveMoveX = moveX
            effectiveMoveY = moveY
            effectiveSprint = isSprintPressed
            effectiveCrouch = isCrouchPressed
        }

        updatePlayer(dt, effectiveMoveX, effectiveMoveY, effectiveSprint, effectiveCrouch)
        updateGuards(dt)
        updateSmokeAndParticles(dt)
        updateInteractables()
        updateCamera(dt)
    }

    private fun updatePlayer(
        dt: Float,
        moveX: Float,
        moveY: Float,
        isSprint: Boolean,
        isCrouch: Boolean
    ) {
        if (player.leapOfFaithProgress > 0f) {
            // Animating Leap of Faith
            player.leapOfFaithProgress += dt * 1.8f
            if (player.leapOfFaithProgress >= 1f) {
                player.leapOfFaithProgress = 0f
                player.elevationZ = 0
                player.isHiddenInHay = true
                player.posture = PlayerPosture.IN_HAYSTACK
                audioEngine.playParkourStep()
                vibrate(150)
            }
            return
        }

        if (player.attackAnimTimer > 0f) {
            player.attackAnimTimer -= dt
            if (player.attackAnimTimer <= 0f) {
                player.posture = if (player.inStealth) PlayerPosture.CROUCH_STEALTH else PlayerPosture.STAND
            }
            return
        }

        // Eagle Vision timer
        if (player.isEagleVisionActive) {
            player.eagleVisionTimer += dt
            if (player.eagleVisionTimer > 15f) {
                // Auto cooldown
                player.isEagleVisionActive = false
                player.eagleVisionTimer = 0f
            }
        }

        val moveInput = Vector2D(moveX, moveY)
        val inputMagnitude = moveInput.length().coerceIn(0f, 1f)

        if (inputMagnitude > 0.1f) {
            player.facingAngle = atan2(moveY, moveX)
            player.isHiddenInHay = false

            // Speed calculation
            val speed = when {
                isSprint -> 280f
                isCrouch -> 120f
                else -> 175f
            }

            val nextPos = player.pos + moveInput.normalized() * (speed * inputMagnitude * dt)

            // Building collision and parkour climb detection
            val collidesWith = checkBuildingCollision(nextPos)
            if (collidesWith != null) {
                if (isSprint && player.elevationZ < collidesWith.elevationZ) {
                    // Parkour climb UP!
                    player.elevationZ = collidesWith.elevationZ
                    player.posture = PlayerPosture.ROOFTOP_PERCH
                    audioEngine.playParkourStep()
                    vibrate(40)
                    player.pos = nextPos
                } else if (player.elevationZ == collidesWith.elevationZ) {
                    // Running on rooftop of building
                    player.pos = nextPos
                    player.posture = PlayerPosture.SPRINT_PARKOUR
                }
                // Else blocked at ground level
            } else {
                // No building directly underfoot
                if (player.elevationZ > 0) {
                    // Walking off rooftop: if crouching, controlled parkour descent down to street
                    if (isCrouch) {
                        player.elevationZ = 0
                        audioEngine.playParkourStep()
                        vibrate(50)
                    } else if (isSprint) {
                        // Check if jumping into a haystack (Leap of Faith!)
                        val nearbyHay = haystacks.find { it.pos.distanceTo(nextPos) < 55f }
                        if (nearbyHay != null) {
                            startLeapOfFaith(nearbyHay)
                            return
                        }
                    }
                }
                player.pos = nextPos
            }

            // Update Posture
            player.posture = when {
                isSprint -> PlayerPosture.SPRINT_PARKOUR
                isCrouch -> PlayerPosture.CROUCH_STEALTH
                player.elevationZ > 0 -> PlayerPosture.ROOFTOP_PERCH
                else -> PlayerPosture.STAND
            }
            player.inStealth = isCrouch
        } else {
            // Standing or crouching
            player.posture = when {
                player.isHiddenInHay -> PlayerPosture.IN_HAYSTACK
                player.isBlended -> PlayerPosture.BLENDED_IN_CROWD
                isCrouch -> PlayerPosture.CROUCH_STEALTH
                player.elevationZ > 0 -> PlayerPosture.ROOFTOP_PERCH
                else -> PlayerPosture.STAND
            }
            player.inStealth = isCrouch
        }

        // Check Social Stealth / Blended in Crowd
        if (player.elevationZ == 0 && !player.isHiddenInHay) {
            val nearbyCrowdCount = crowds.count { it.pos.distanceTo(player.pos) < 65f }
            player.isBlended = nearbyCrowdCount >= 3
        } else {
            player.isBlended = false
        }

        // Health regeneration when undetected
        if (detectedCount == 0 && player.health < player.maxHealth) {
            player.health = (player.health + dt * 6f).coerceAtMost(player.maxHealth)
        }
    }

    private fun checkBuildingCollision(pos: Vector2D): Building? {
        return buildings.find { b ->
            pos.x >= b.x && pos.x <= b.x + b.width &&
                    pos.y >= b.y && pos.y <= b.y + b.height
        }
    }

    private fun startLeapOfFaith(haystack: Haystack) {
        player.leapOfFaithProgress = 0.05f
        player.posture = PlayerPosture.LEAP_OF_FAITH
        audioEngine.playEagleCry()
        vibrate(200)
    }

    private fun updateGuards(dt: Float) {
        var activeAlerts = 0

        for (guard in guards) {
            if (guard.state == GuardState.DEAD) continue

            // Stun recovery from smoke bomb
            if (guard.stunnedTimer > 0f) {
                guard.stunnedTimer -= dt
                guard.state = GuardState.STUNNED
                continue
            }

            // Patrol movement
            if (guard.patrolPath.isNotEmpty() && guard.state == GuardState.UNAWARE) {
                val dest = guard.patrolPath[guard.currentPatrolIndex]
                val diff = dest - guard.pos
                if (diff.length() < 12f) {
                    guard.currentPatrolIndex = (guard.currentPatrolIndex + 1) % guard.patrolPath.size
                } else {
                    guard.pos = guard.pos + diff.normalized() * (45f * dt)
                    guard.facingAngle = atan2(diff.y, diff.x)
                }
            }

            // Vision Cone & Detection calculation
            val canSeePlayer = checkGuardCanSeePlayer(guard)

            if (canSeePlayer) {
                val dist = guard.pos.distanceTo(player.pos)
                val fillRate = when {
                    dist < 70f -> 1.8f
                    dist < 140f -> 0.9f
                    else -> 0.45f
                }
                guard.detectionMeter = (guard.detectionMeter + fillRate * dt).coerceAtMost(1f)

                if (guard.detectionMeter >= 1f) {
                    if (guard.state != GuardState.COMBAT) {
                        guard.state = GuardState.COMBAT
                        audioEngine.playGuardAlert()
                        vibrate(100)
                        bannerMessage = "ALERT! Guard sounded alarm!"
                        bannerTimer = 3f
                    }
                    activeAlerts++
                    lastKnownPosition = player.pos
                } else if (guard.detectionMeter > 0.35f) {
                    guard.state = GuardState.SUSPICIOUS
                }
            } else {
                // Losing sight
                if (guard.state == GuardState.COMBAT) {
                    // Move towards Last Known Position
                    lastKnownPosition?.let { lkp ->
                        val diff = lkp - guard.pos
                        if (diff.length() > 20f) {
                            guard.pos = guard.pos + diff.normalized() * (75f * dt)
                            guard.facingAngle = atan2(diff.y, diff.x)
                            guard.state = GuardState.INVESTIGATING
                        } else {
                            guard.state = GuardState.SUSPICIOUS
                        }
                    }
                } else if (guard.state == GuardState.INVESTIGATING || guard.state == GuardState.SUSPICIOUS) {
                    guard.detectionMeter = (guard.detectionMeter - 0.25f * dt).coerceAtLeast(0f)
                    if (guard.detectionMeter <= 0f) {
                        guard.state = GuardState.UNAWARE
                    }
                }
            }

            // Guard combat attack if in range
            if (guard.state == GuardState.COMBAT && guard.pos.distanceTo(player.pos) < 55f) {
                guard.attackCooldown -= dt
                if (guard.attackCooldown <= 0f) {
                    guard.attackCooldown = 1.4f
                    player.health -= 18f
                    vibrate(150)
                    spawnHitSparks(player.pos)
                    if (player.health <= 0f) {
                        bannerMessage = "DESYNCHRONIZED! You were killed in combat."
                        bannerTimer = 4f
                        player.health = 100f
                        player.pos = Vector2D(400f, 600f)
                    }
                }
            }
        }

        detectedCount = activeAlerts
    }

    private fun checkGuardCanSeePlayer(guard: Guard): Boolean {
        if (player.isHiddenInHay) return false
        if (isPosInSmoke(guard.pos) || isPosInSmoke(player.pos)) return false

        // Elevation advantage: guards on ground rarely spot assassins on rooftops unless within 80 units
        if (guard.elevationZ == 0 && player.elevationZ >= 2) {
            val dist = guard.pos.distanceTo(player.pos)
            return dist < 90f && !player.inStealth
        }

        // Crowds: social stealth
        if (player.isBlended) {
            return guard.pos.distanceTo(player.pos) < 40f
        }

        val toPlayer = player.pos - guard.pos
        val dist = toPlayer.length()
        val maxDist = if (player.inStealth) 110f else 220f

        if (dist > maxDist) return false

        // Check angle inside vision cone (+/- 45 degrees)
        val angleToPlayer = atan2(toPlayer.y, toPlayer.x)
        var angleDiff = kotlin.math.abs(angleToPlayer - guard.facingAngle)
        while (angleDiff > PI) angleDiff -= (2 * PI).toFloat()
        angleDiff = kotlin.math.abs(angleDiff)

        return angleDiff < (PI / 3.2f) // ~56 degrees FOV
    }

    private fun isPosInSmoke(pos: Vector2D): Boolean {
        return smokeClouds.any { it.pos.distanceTo(pos) < it.radius }
    }

    private fun updateSmokeAndParticles(dt: Float) {
        // Smoke clouds
        val it = smokeClouds.iterator()
        while (it.hasNext()) {
            val cloud = it.next()
            cloud.duration -= dt
            if (cloud.duration <= 0f) {
                it.remove()
            } else {
                // Stun nearby guards
                guards.forEach { g ->
                    if (g.state != GuardState.DEAD && g.pos.distanceTo(cloud.pos) < cloud.radius) {
                        g.stunnedTimer = 5f
                        g.state = GuardState.STUNNED
                    }
                }
            }
        }

        // Ambient particles (revolutionary embers, smoke, dust)
        if (particles.size < 40) {
            particles.add(
                Particle(
                    pos = player.pos + Vector2D((Math.random().toFloat() - 0.5f) * 600f, (Math.random().toFloat() - 0.5f) * 500f),
                    vel = Vector2D((Math.random().toFloat() - 0.5f) * 15f, -20f - Math.random().toFloat() * 25f),
                    life = 3f + Math.random().toFloat() * 3f,
                    maxLife = 6f,
                    color = if (Math.random() > 0.5) 0xFFFF9933 else 0xFFCCD0DF,
                    size = 3f + Math.random().toFloat() * 4f
                )
            )
        }

        val partIt = particles.iterator()
        while (partIt.hasNext()) {
            val p = partIt.next()
            p.pos = p.pos + p.vel * dt
            p.life -= dt
            if (p.life <= 0f) partIt.remove()
        }
    }

    private fun updateInteractables() {
        // Check Contextual Assassination Target
        var bestTarget: Guard? = null
        var isAir = false

        for (g in guards) {
            if (g.state == GuardState.DEAD) continue
            val dist = g.pos.distanceTo(player.pos)

            if (player.elevationZ >= 1 && g.elevationZ == 0 && dist < 170f) {
                // Air Assassination possible!
                bestTarget = g
                isAir = true
                break
            } else if (dist < 68f && player.elevationZ == g.elevationZ) {
                // Ground or Rooftop Stealth Strike
                bestTarget = g
                isAir = false
                break
            }
        }
        canAssassinateTarget = bestTarget
        isAirAssassinationPossible = isAir

        // Check Viewpoints
        canSynchronizeViewpoint = viewpoints.find {
            !it.isSynchronized && it.pos.distanceTo(player.pos) < 60f && player.elevationZ >= 2
        }

        // Check Loot chests
        canLootChest = lootChests.find {
            !it.isOpened && it.pos.distanceTo(player.pos) < 50f && player.elevationZ == it.elevationZ
        }

        // Check Haystack hiding
        canHideInHaystack = haystacks.find {
            it.pos.distanceTo(player.pos) < 45f && player.elevationZ == 0
        }

        // Check Prisoner Cages (Public Act: Liberate)
        canLiberateCage = prisonerCages.find {
            !it.isLiberated && it.pos.distanceTo(player.pos) < 55f && player.elevationZ == 0
        }
    }

    private fun updateCamera(dt: Float) {
        if (isSynchronizingViewpoint) {
            syncCameraAngle += dt * 45f
            if (syncCameraAngle >= 360f) {
                isSynchronizingViewpoint = false
                syncCameraAngle = 0f
            }
        }
        // Smooth camera follow
        cameraX += (player.pos.x - cameraX) * (dt * 6f)
        cameraY += (player.pos.y - cameraY) * (dt * 6f)
    }

    // ACTIONS

    fun triggerAssassination(): Boolean {
        val target = canAssassinateTarget ?: return false

        target.state = GuardState.DEAD
        target.health = 0f
        player.attackAnimTimer = 0.45f
        player.posture = PlayerPosture.ATTACKING

        if (isAirAssassinationPossible) {
            // Jump down to target
            player.pos = target.pos
            player.elevationZ = target.elevationZ
            bannerMessage = "AIR ASSASSINATION! Perfect execution."
        } else {
            bannerMessage = "HIDDEN BLADE ASSASSINATION!"
        }
        bannerTimer = 3.5f

        audioEngine.playHiddenBlade()
        audioEngine.playAssassinationImpact()
        vibrate(250)
        spawnBloodSparks(target.pos)
        onStealthKillAchieved()

        // Check Mission Target assassination!
        if (target.type == GuardType.MISSION_TARGET) {
            isMissionCompleted = true
            val stealthBonus = detectedCount == 0
            bannerMessage = "MEMORY SYNCHRONIZED: $activeTargetName ELIMINATED!"
            bannerTimer = 6f
            audioEngine.playEagleCry()
            onMissionComplete(activeMissionId, stealthBonus, 1200, 400)
        } else {
            // Faction standing impacts based on guard alignment
            when (target.type) {
                GuardType.ROYALIST_SOLDIER, GuardType.ELITE_INQUISITOR, GuardType.ROOFTOP_SNIPER -> {
                    onFactionStandingChanged("royalists", -4, "Royalist Sentry Neutralized")
                    onFactionStandingChanged("sanculottes", 3, "San-culottes Cheered Defeat")
                    onFactionStandingChanged("assassins", 2, "Brotherhood Creed Upheld")
                }
                GuardType.REVOLUTIONARY_MILITIA -> {
                    onFactionStandingChanged("sanculottes", -5, "Revolutionary Citizen Harmed")
                    onFactionStandingChanged("royalists", 2, "Order Restored")
                }
                else -> {}
            }
        }

        return true
    }

    fun useGadget(): Boolean {
        return when (player.selectedGadget) {
            GadgetType.SMOKE_BOMB -> {
                if (player.smokeBombs > 0) {
                    player.smokeBombs--
                    smokeClouds.add(SmokeCloud(pos = player.pos))
                    audioEngine.playSmokeBomb()
                    vibrate(100)
                    bannerMessage = "Smoke Bomb deployed! Guards blinded."
                    bannerTimer = 2.5f
                    true
                } else {
                    bannerMessage = "Out of Smoke Bombs!"
                    bannerTimer = 2f
                    false
                }
            }
            GadgetType.PHANTOM_BLADE -> {
                if (player.phantomBlades > 0) {
                    // Find nearest guard within 250 units
                    val target = guards.filter { it.state != GuardState.DEAD }
                        .minByOrNull { it.pos.distanceTo(player.pos) }
                    if (target != null && target.pos.distanceTo(player.pos) < 250f) {
                        player.phantomBlades--
                        target.state = GuardState.DEAD
                        audioEngine.playPhantomBlade()
                        spawnBloodSparks(target.pos)
                        vibrate(120)
                        bannerMessage = "Phantom Blade kill: ${target.name}"
                        bannerTimer = 2.5f
                        if (target.type == GuardType.MISSION_TARGET) {
                            isMissionCompleted = true
                            onMissionComplete(activeMissionId, detectedCount == 0, 1200, 400)
                        }
                        true
                    } else {
                        bannerMessage = "No target in Phantom Blade range."
                        bannerTimer = 2f
                        false
                    }
                } else {
                    bannerMessage = "Out of Phantom Blades!"
                    bannerTimer = 2f
                    false
                }
            }
            GadgetType.WHISTLE -> {
                whistle()
                true
            }
        }
    }

    fun whistle() {
        val nearestGuard = guards.filter { it.state == GuardState.UNAWARE || it.state == GuardState.SUSPICIOUS }
            .minByOrNull { it.pos.distanceTo(player.pos) }
        if (nearestGuard != null && nearestGuard.pos.distanceTo(player.pos) < 150f) {
            nearestGuard.state = GuardState.INVESTIGATING
            nearestGuard.investigateTarget = player.pos
            nearestGuard.detectionMeter = 0.4f
            bannerMessage = "Whistle emitted. Guard investigating noise."
            bannerTimer = 2.5f
        } else {
            bannerMessage = "Whistled from cover."
            bannerTimer = 1.5f
        }
    }

    fun toggleEagleVision() {
        player.isEagleVisionActive = !player.isEagleVisionActive
        if (player.isEagleVisionActive) {
            audioEngine.playEagleVisionPulse()
            vibrate(80)
            bannerMessage = "EAGLE VISION: Target & Guards marked."
            bannerTimer = 2f
        }
    }

    fun synchronizeViewpoint(): Boolean {
        val vp = canSynchronizeViewpoint ?: return false
        vp.isSynchronized = true
        isSynchronizingViewpoint = true
        audioEngine.playEagleCry()
        vibrate(300)
        bannerMessage = "SYNCHRONIZED: ${vp.name} (+200 Livres, +100 Sync)"
        bannerTimer = 4.5f
        onViewpointSynced(vp.name)
        return true
    }

    fun lootChest(): Boolean {
        val chest = canLootChest ?: return false
        chest.isOpened = true
        player.livresEarnedThisRun += chest.livres
        audioEngine.playHiddenBlade()
        vibrate(60)
        bannerMessage = "Looted Chest: +${chest.livres} Livres!"
        bannerTimer = 2.5f
        return true
    }

    fun toggleHaystackHide(): Boolean {
        val hay = canHideInHaystack ?: return false
        player.isHiddenInHay = !player.isHiddenInHay
        player.posture = if (player.isHiddenInHay) PlayerPosture.IN_HAYSTACK else PlayerPosture.STAND
        audioEngine.playParkourStep()
        vibrate(50)
        bannerMessage = if (player.isHiddenInHay) "Hidden in Haystack. Undetectable." else "Exited Haystack."
        bannerTimer = 2f
        return true
    }

    /**
     * Public Act: Liberate Captured Patriots from Scaffold Cell
     * Greatly boosts San-culottes standing, enrages Royalist Court.
     */
    fun liberatePrisoners(): Boolean {
        val cage = canLiberateCage ?: return false
        cage.isLiberated = true
        player.livresEarnedThisRun += 150
        audioEngine.playHiddenBlade()
        vibrate(120)

        // Spawn celebration particles
        for (i in 0 until 16) {
            particles.add(
                Particle(
                    pos = cage.pos,
                    vel = Vector2D((Math.random().toFloat() - 0.5f) * 140f, -40f - Math.random().toFloat() * 60f),
                    life = 1.2f,
                    maxLife = 1.2f,
                    color = if (i % 2 == 0) 0xFF2B5CB8 else 0xFFC22234, // Tricolor spark
                    size = 5f
                )
            )
        }

        bannerMessage = "PUBLIC ACT: Prisoners Liberated! Patriots pledge solidarity (+18 San-culottes, -20 Royalists)"
        bannerTimer = 4.5f

        onFactionStandingChanged("sanculottes", 18, "Liberated Scaffold Prisoners")
        onFactionStandingChanged("royalists", -20, "Royal Court Decrees Defied")
        onFactionStandingChanged("assassins", 6, "Protected the Innocent")
        return true
    }

    /**
     * Public Act: Toss Livres to Incite Crowd Riot
     * Stuns guards, creates crowd barrier, boosts standing with San-culottes and Smugglers.
     */
    fun tossCoinsAndInciteRiot(): Boolean {
        val nearbyCrowds = crowds.filter { it.pos.distanceTo(player.pos) < 140f }
        if (nearbyCrowds.isEmpty()) {
            bannerMessage = "No crowd nearby to incite!"
            bannerTimer = 2f
            return false
        }

        // Spawn golden coin particles
        for (i in 0 until 18) {
            particles.add(
                Particle(
                    pos = player.pos,
                    vel = Vector2D((Math.random().toFloat() - 0.5f) * 160f, (Math.random().toFloat() - 0.5f) * 160f),
                    life = 1.0f,
                    maxLife = 1.0f,
                    color = 0xFFFFD700, // Gold
                    size = 4f
                )
            )
        }

        // Stun nearby guards with crowd rush
        guards.forEach { g ->
            if (g.state != GuardState.DEAD && g.pos.distanceTo(player.pos) < 160f) {
                g.stunnedTimer = 7f
                g.state = GuardState.STUNNED
            }
        }

        audioEngine.playParkourStep()
        vibrate(80)
        bannerMessage = "PUBLIC ACT: Crowd Riot Incited! Guards overwhelmed by mob (+8 San-culottes, +5 Smugglers)"
        bannerTimer = 3.8f

        onFactionStandingChanged("sanculottes", 8, "Incited Crowd Distraction")
        onFactionStandingChanged("smugglers", 5, "Street Chaos Exploited")
        return true
    }

    private fun spawnBloodSparks(pos: Vector2D) {
        for (i in 0 until 12) {
            particles.add(
                Particle(
                    pos = pos,
                    vel = Vector2D((Math.random().toFloat() - 0.5f) * 120f, (Math.random().toFloat() - 0.5f) * 120f),
                    life = 0.5f + Math.random().toFloat() * 0.4f,
                    maxLife = 0.9f,
                    color = 0xFFCC1122,
                    size = 5f + Math.random().toFloat() * 4f
                )
            )
        }
    }

    private fun spawnHitSparks(pos: Vector2D) {
        for (i in 0 until 8) {
            particles.add(
                Particle(
                    pos = pos,
                    vel = Vector2D((Math.random().toFloat() - 0.5f) * 160f, (Math.random().toFloat() - 0.5f) * 160f),
                    life = 0.4f,
                    maxLife = 0.4f,
                    color = 0xFFFFDD33,
                    size = 4f
                )
            )
        }
    }

    private fun vibrate(durationMs: Long) {
        try {
            vibrator?.vibrate(android.os.VibrationEffect.createOneShot(durationMs, android.os.VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Exception) {}
    }
}
